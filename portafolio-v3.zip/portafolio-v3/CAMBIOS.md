# Portafolio de Norberto Sánchez Cañón: versión 3

Última actualización: 8 de noviembre de 2026 (revisión final antes de publicar)

Dirección del sitio: https://norberto-sanchez-portafolio.vercel.app/ (esta versión reemplaza a la anterior en la misma dirección).

**Respaldo:** la carpeta `portafolio-v2` queda intacta como respaldo, con los prototipos interactivos de e-Core. Esta carpeta, `portafolio-v3`, es la versión para publicar.

## Revisión final antes de publicar (8 nov 2026)

### 1. Huellas Unidas: los cuatro grupos de la arquitectura
**Qué pasaba:**
- El card sorting hablaba de cuatro grupos y el mapa de navegación mostraba cuatro secciones.
- En cambio, "De los hallazgos a la arquitectura" solo mostraba tres puntos (Difusión inmediata, Seguimiento en tiempo real y Búsqueda hiperlocal).
- Esos tres puntos mezclaban tarjetas de grupos distintos. Por ejemplo, ponía "compartir en redes" en Búsqueda y reporte, cuando el card sorting lo ubica en Avistamiento.

**Qué dicen los documentos de Norberto:**
- La preentrega del Módulo 4 propone cuatro módulos antes del card sorting: Búsqueda, Avistamiento, Localización y Perfil.
- Después del ejercicio dice: "Después de analizar las categorías creadas por los participantes estas fueron las categorías finales".
- El Figma conserva los cuatro grupos finales con sus tarjetas.
- Perfil sí es uno de los cuatro grupos documentados (Mis reportes activos, Perfil del usuario, Ficha de la mascota y Guía de primeros auxilios). No es una sección añadida después.

**Cómo se resolvió:**
- La sección ahora muestra los cuatro grupos con las tarjetas correctas de cada uno.
- Cada grupo se relaciona con el hallazgo que atiende.
- Perfil aclara que no sale de un hallazgo puntual: reúne la información propia del usuario y la guía de consulta.
- Una frase corta explica el origen: los grupos parten de la organización de contenido que propuso antes del ejercicio y los mantuvo como categorías finales después de analizar a los participantes.
- En el texto del card sorting, "A partir de esos patrones definí cuatro grupos" pasó a "Después de analizar esos patrones, definí los cuatro grupos finales", para no atribuirle al ejercicio más de lo que muestra.
- El pie del mapa de navegación nombra las cuatro secciones.

### 2. Revisión editorial
- **Huellas Unidas:**
  - *Mi rol* ahora incluye el diseño visual (moodboard y UI kit ya estaban en el caso).
  - *Métodos:* "prototipado en Figma" pasó a "wireframes en Figma". No hay un prototipo documentado.
  - La ficha tenía dos veces "Estado". El segundo pasó a "Resultado: todavía no hay resultados de uso, es un proyecto académico en curso".
  - Wireframes de baja fidelidad: "validar el orden de los pasos" pasó a "definir el orden de los pasos", porque no hubo una prueba con usuarios.
  - Benchmark: se corrigió una frase confusa ("observé que no encontré cobertura").
- **Onboarding:**
  - La adaptación responsive decía "cuatro tamaños" y nombraba solo tres dispositivos. Ahora dice "cuatro tamaños de pantalla, para la caja, la tablet del salón y el computador de administración".
  - Se unificó "tablet del mesero" a "tablet del salón", como en el contexto.
- **Domicilios:**
  - La ficha decía "Móvil, tablet y escritorio", pero tres textos decían solo móvil y escritorio.
  - Los archivos originales incluyen las pantallas para tablet, así que los cuatro textos ahora dicen móvil, tablet y escritorio.
  - La galería sigue mostrando móvil y escritorio.
- **Home, cargo en e-Core:** "Diseñador web en agencia" pasó a "Diseñador web UX/UI en agencia", igual que en el CV.
- **Se verificaron y se mantienen:**
  - Más de 10 años en diseño.
  - Alrededor de 4 años en proyectos digitales.
  - Unos 3 años como único diseñador de producto en Precompro.
  - En Domicilios, solo el diseño de cómo se elige y se confirma el pago, no las integraciones.
  - Chica Cuántica entregada al cliente, con publicación sin confirmar.
  - Fraternidad como prueba técnica.
  - El 30 % de Fairplay como meta y no como resultado.
  - Inglés básico.
- **Afirmaciones del caso Huellas Unidas comprobadas en los documentos de investigación y arquitectura:**
  - Las cinco entrevistas con el mismo patrón.
  - Los carteles.
  - La tab bar de los wireframes.
  - Los tres pasos del formulario.
  - El pin en el mapa.
  - El avatar ilustrado.
- **CV:** no se modificó. No se encontraron diferencias con el portafolio en fechas, cargos, empresas, herramientas ni idioma.

### 3. Imágenes para compartir en redes
- **Problema:** las páginas de proyecto usaban imágenes WebP para la vista previa en redes. LinkedIn y otras redes no siempre las muestran.
- **Solución:**
  - Se crearon imágenes JPG de 1200 × 630 px para cada proyecto, en la carpeta `assets/og/`.
  - Se agregaron las etiquetas og:image:width, og:image:height y og:image:alt.
  - La home sigue usando `og-portafolio.jpg`.

### 4. Pruebas técnicas ejecutadas
**En navegador real (Chromium), en 1440, 820 y 390 px, en las 9 páginas:**
- Carga sin errores de JavaScript en consola y sin solicitudes fallidas.
- Todas las imágenes cargan. Se forzó la carga de las imágenes diferidas y se comprobó cada una.
- Sin desbordamiento horizontal.
- Un solo H1 por página, sin IDs duplicados y todas las imágenes con texto alternativo.
- Sin enlaces internos ni anclas rotas.

**Funciones:**
- **Menú móvil:**
  - Abre.
  - Se usa con teclado: el foco entra y se queda dentro al tabular.
  - Se cierra con Escape y el foco vuelve al botón Menú.
- **Galería ampliable:** abre y se cierra con Escape.
- **Card sorting:** agrupa las tarjetas en los cuatro grupos.
- **Carruseles de pantallas:** las flechas desplazan.
- **Comparador de baja y media fidelidad:** el control se mueve.
- **Onboarding:**
  - Cambia entre los cuatro tamaños de pantalla.
  - Los puntos avanzan ("2 de 4").
- **Domicilios:** las pestañas de móvil y escritorio funcionan.
- **e-Core:** no queda ningún prototipo en sus cuatro páginas.

**Servidor local por HTTP (simula la publicación):**
- El CV responde 200 como application/pdf (2 páginas, inglés básico).
- sitemap.xml, robots.txt y las imágenes de vista previa responden 200 con el tipo correcto.
- Ninguna respuesta con error.

**Revisión de archivos:**
- Las rutas de imágenes, CSS y JavaScript existen, incluidas las imágenes de los carruseles.
- **Metadatos en las 9 páginas:**
  - canonical y og:url coinciden con la dirección de cada página.
  - og:image apunta a un JPG que existe.
  - Tienen título, descripción y lang="es".
- **Sitemap y robots:**
  - sitemap.xml tiene exactamente las 9 páginas.
  - robots.txt apunta al sitemap.
- No queda ninguna mención a FIRU.

**Validación de código:**
- JavaScript sin errores de sintaxis (node --check).
- HTML con etiquetas bien abiertas y cerradas en las 9 páginas.
- CSS con llaves balanceadas.

### 5. Pruebas que no se pudieron hacer
- **Google Fonts:** el entorno de pruebas no tiene acceso a internet, así que las páginas se probaron con la tipografía de respaldo. Inter se carga desde Google Fonts y debería verse normal al publicar.
- **Validación oficial del W3C:** no se pudo usar. Solo se revisó que las etiquetas estén bien abiertas y cerradas.
- **Vista previa real en redes:** no se probó cómo se ve el enlace en LinkedIn, WhatsApp ni Facebook. Requiere el sitio publicado; se puede revisar con el inspector de publicaciones de LinkedIn.
- **Dispositivos reales:** no se probó en un celular ni en una tablet físicos ni en Safari. Las pruebas fueron en Chromium con los tamaños de pantalla simulados.
- **Enlaces externos:** no se comprobó que respondan (LinkedIn, Behance, WhatsApp, el estudio citado).

### Estado para publicar
**No hay bloqueos técnicos:** el sitio se puede publicar en Vercel subiendo el contenido de esta carpeta.

**Siguen pendientes, sin bloquear la publicación:**
- La foto profesional.
- Confirmar la publicación de Chica Cuántica.
- Los porcentajes de la encuesta de Huellas Unidas.

## Cambios de la versión 3

### e-Core: sin prototipos interactivos
- **Qué se quitó:** las recreaciones de las interacciones de Figma en PlanAutos, Fairplay, Arch Light y Chica Cuántica, porque no se veían igual que en Figma.
- **Qué se conserva:** los textos de proceso y decisiones.
  - Se sigue mencionando que Norberto diseñó prototipos y microinteracciones en Figma, porque es parte de su trabajo.
  - Ya no se dice que estén recreados en la web.
- **Arch Light:** sin el prototipo, el caso se quedaba sin imágenes. Ahora muestra:
  - la home a pantalla completa;
  - la grilla de proyectos;
  - la galería emergente.
- **Chica Cuántica:** muestra la página de servicios y el popup de suscripción como imágenes fijas.

### Calidad de las imágenes
- **Páginas completas de e-Core a 1440 px (el ancho de diseño en Figma):**
  - PlanAutos y Chica Cuántica antes estaban reducidas a 1032 y 1100 px.
  - Fairplay: con el enlace a su archivo de Figma, la home se exportó a su tamaño original (1440 × 6848 px). Con ella se regeneraron la imagen del listado, la miniatura y la imagen para compartir en redes.
- **Domicilios en escritorio:** se usan los archivos originales a 1920 px, en lugar de la versión reducida a 1600 px.
- **Compresión:** las imágenes se generaron de nuevo con una compresión más suave.
- **Pantallas de Huellas Unidas:** están al tamaño real del frame en Figma (402 × 874 px). La conexión con Figma no permite exportar al doble de resolución. Si se quieren más nítidas en pantallas retina, hay que exportarlas a 2x desde Figma y reemplazar los archivos `hu-*.webp`.
- **Archivos sin uso:** se retiraron de la carpeta v3 las imágenes que ya no se usan (prototipos y versiones viejas de FIRU). Siguen en la v2.

### Home
- **Foto de "Cómo trabajo":** ahora tiene la misma forma ovalada y el mismo ancho máximo que la foto del inicio.
- **Foto principal:** se mantiene la actual como recurso provisional. Se recomienda reemplazarla por un retrato profesional, frontal, natural y con fondo sencillo, tomado a Norberto. No se generaron ni se usaron fotos ficticias.

### FIRU pasa a llamarse Huellas Unidas
- **Nombre:** cambió en el título, los textos, los textos alternativos y los metadatos.
- **Dirección de la página:** ahora es `trabajo/huellas-unidas.html`, actualizada en el sitemap.
- **Material nuevo del Figma "Proyecto app Huellas unidas":**
  - Imagen principal nueva: la home en baja fidelidad, en media fidelidad y con diseño visual.
  - Baja fidelidad: las 9 pantallas del reporte.
  - Media fidelidad: ahora tiene las 9 pantallas del reporte (antes solo 3).
  - Moodboard y paleta:
    - Las tres palabras clave: confianza, esperanza y claridad.
    - Los cinco colores: #36ECDE, #3F5C40, #F6694E, #F7F9E1 y #B2E7D5.
  - UI kit: barra de estado, tab bar, buscador, campos, alerta, tarjeta de mascota, íconos y botón con cuatro estados (principal, secundario, error y desactivado).
  - Media fidelidad con diseño visual: las 9 pantallas del reporte con fotos, color y el nombre de la app.
  - Tab bar: el texto aclara que en los wireframes era Inicio, Mis alertas, Reportar y Perfil, y que en la versión con diseño visual pasó a Búsqueda, Avistamiento, Alertas y Perfil.
  - Uso de IA: se agregó que usó ChatGPT para generar ideas de color a partir de los colores base que él seleccionó (así lo dice el moodboard).

### Huellas Unidas: ajustes del brief
1. **Hallazgo de las entrevistas:**
   - El título ahora es "Un patrón que apareció en las cinco entrevistas".
   - La descripción es la del brief.
2. **Card sorting:**
   - La explicación del 32 % es la del brief.
   - Se conservan los 4 participantes, las 15 tarjetas y los cuatro grupos.
3. **Dato del 70 %: retirado.**
   - No se encontró un estudio que respalde esa cifra y esa distancia.
   - La encuesta de la ASPCA (Weiss, Slater y Lord, revista *Animals*, 2012) no es de JAVMA y no mide distancias: dice que buscar en el vecindario fue la forma más común de recuperar a un perro.
   - El estudio de Huang y otros (*Animals*, 2018) habla de gatos: el 75 % apareció a menos de 500 m del punto de escape.
   - Ninguno dice "70 % a menos de un kilómetro".
   - El hallazgo quedó como descripción cualitativa ("La búsqueda empieza cerca de casa"), con un enlace visible al estudio de 2012.
   - Enlace: https://pmc.ncbi.nlm.nih.gov/articles/PMC4494319/
4. **Benchmark:**
   - Ahora dice que lo de PawBoost y Finding Rover (interfaz en inglés, sin cobertura encontrada en Bogotá, problemas de jerarquía y contraste) fue una observación del benchmark hecho en 2026, no una descripción permanente de los servicios.
   - Lo que se pudo comprobar: el FAQ de PawBoost dice que tiene comunidad activa en Estados Unidos, Canadá, Reino Unido, Australia, Sudáfrica y Brasil.
   - Una nota de El Tiempo de 2017 dice que Finding Rover solo estaba disponible en Estados Unidos, Canadá, Australia y Nueva Zelanda.
   - No se agregaron estos datos al portafolio.

### Verificación final
- **Las 9 páginas, en 1440, 820 y 390 px de ancho:**
  - Sin desbordamiento horizontal.
  - Sin imágenes rotas.
  - Sin errores en consola.
  - Sin enlaces ni anclas rotas.
- **Navegación:**
  - El menú móvil se puede usar con teclado.
  - Los puntos del Onboarding funcionan.
  - No queda ningún prototipo en las páginas de e-Core.
- **Publicación:**
  - URL canónica, og:url y og:image correctas.
  - `sitemap.xml` con las 9 direcciones (incluida `huellas-unidas.html`).
  - `robots.txt` apunta al sitemap.
- **Sin cambios:**
  - Posicionamiento, fechas, años de experiencia e identidad visual.
  - CV: se revisó y no tenía inconsistencias con estos cambios (no menciona FIRU).

## Datos pendientes de confirmar por Norberto
1. **Huellas Unidas, porcentajes de la encuesta:** el documento de investigación tiene porcentajes que no cuadran con 14 respuestas. En el portafolio solo se usan conteos ("7 de 14").
2. **Chica Cuántica:** si se confirma la publicación, se actualiza el estado.
3. **Foto principal:** reemplazarla cuando tenga un retrato profesional.

## Cómo regenerar las páginas
Los textos están en `build.py`. Después de editarlo, ejecuta `python3 build.py` dentro de esta carpeta: se generan `index.html` y `trabajo/*.html`.
