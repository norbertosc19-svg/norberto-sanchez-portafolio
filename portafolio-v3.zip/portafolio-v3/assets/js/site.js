(function(){
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const fine = matchMedia('(hover: hover) and (pointer: fine)').matches;
  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => Array.from(r.querySelectorAll(s));
  const IMG = document.body.dataset.img || 'assets/img/';
  if (!document.body.dataset.tone) document.body.dataset.tone = 'pizarra';

  /* Tono por sección */
  const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) document.body.dataset.tone = e.target.dataset.tone; }), { rootMargin:'-45% 0px -45% 0px' });
  $$('main [data-tone]').forEach(s => io.observe(s));

  /* Header y menú */
  const top = $('#top');
  addEventListener('scroll', () => top && top.classList.toggle('is-scrolled', scrollY > 20), { passive:true });
  const menu = $('#menu'), menuBtn = $('#menuBtn'), menuClose = $('#menuClose');
  if (menu && menuBtn) {
    const main = $('#main'); const setMenu = open => { menu.classList.toggle('is-open', open); if (main) main.inert = open; if (top) top.querySelector('.nav') && (top.querySelector('.nav').inert = open); menuBtn.setAttribute('aria-expanded', open); document.documentElement.style.overflow = open ? 'hidden' : ''; if (open) setTimeout(() => menuClose.focus(), 50); else menuBtn.focus({preventScroll:true}); };
    menuBtn.addEventListener('click', () => setMenu(true));
    menuClose.addEventListener('click', () => setMenu(false));
    $$('#menu nav a').forEach(a => a.addEventListener('click', () => setMenu(false)));
    addEventListener('keydown', e => {
      if (!menu.classList.contains('is-open')) return;
      if (e.key === 'Escape') { setMenu(false); return; }
      if (e.key === 'Tab') {
        const f = $$('a[href], button', menu).filter(el => el.offsetParent !== null);
        const first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    });
  }

  /* Momento de carga */
  if (!reduce) {
    $$('[data-rise] .l > span').forEach((s, i) => s.animate([{ transform:'translateY(105%)' }, { transform:'none' }], { duration:900, delay:80 + i*100, easing:'cubic-bezier(.2,.7,.1,1)', fill:'backwards' }));
    const pill = $('.face__pill');
    if (pill) pill.animate([{ clipPath:'inset(100% 0 0 0 round 999px)' }, { clipPath:'inset(0 0 0 0 round 999px)' }], { duration:1100, delay:250, easing:'cubic-bezier(.2,.7,.1,1)', fill:'backwards' });
  }

  /* Vista previa que sigue al mouse en el listado */
  const peek = $('#peek'), peekImg = $('#peekImg');
  if (peek && fine && !reduce) {
    let x = 0, y = 0, px = 0, py = 0, raf = null;
    const loop = () => { px += (x - px) * .18; py += (y - py) * .18; peek.style.left = px + 'px'; peek.style.top = py + 'px'; raf = Math.abs(x - px) + Math.abs(y - py) > .5 ? requestAnimationFrame(loop) : null; };
    $$('#index a[data-peek]').forEach(a => {
      const i = new Image(); i.src = a.dataset.peek;
      a.addEventListener('mouseenter', e => { peekImg.src = a.dataset.peek; if (!peek.classList.contains('is-on')) { px = x = e.clientX; py = y = e.clientY; peek.style.left = px + 'px'; peek.style.top = py + 'px'; } peek.classList.add('is-on'); });
      a.addEventListener('mouseleave', () => peek.classList.remove('is-on'));
    });
    addEventListener('mousemove', e => { x = e.clientX; y = e.clientY; if (!raf && peek.classList.contains('is-on')) raf = requestAnimationFrame(loop); }, { passive:true });
    addEventListener('scroll', () => peek.classList.remove('is-on'), { passive:true });
  }

  /* Píldoras que se abren con el scroll */
  const pills = $$('[data-pill]');
  if (pills.length && !reduce) {
    const tick = () => { const vh = innerHeight; pills.forEach(p => { const r = p.getBoundingClientRect(); const t = Math.min(1, Math.max(0, (vh - r.top) / (vh * .75))); const e = 1 - Math.pow(1 - t, 3); p.style.setProperty('--r', (600*(1-e) + 20*e).toFixed(1) + 'px'); p.style.setProperty('--x', (16*(1-e)).toFixed(2) + '%'); }); };
    addEventListener('scroll', () => requestAnimationFrame(tick), { passive:true }); addEventListener('resize', tick); tick();
  }

  /* Lightbox y cursor */
  const lb = $('#lb'), lbImg = $('#lbImg'), lbCap = $('#lbCap');
  let group = [], gi = 0;
  const show = i => { gi = (i + group.length) % group.length; const im = group[gi]; lbImg.src = im.currentSrc || im.src; lbImg.alt = im.alt; lbCap.textContent = im.dataset.cap || im.alt; $('#lbPrev').hidden = $('#lbNext').hidden = group.length < 2; };
  const open = img => { const g = img.dataset.group; group = g ? $$(`img[data-zoom][data-group="${g}"]`) : [img]; show(group.indexOf(img)); if (lb.showModal) lb.showModal(); else lb.setAttribute('open', ''); };
  if (lb) {
    $('#lbClose').addEventListener('click', () => lb.close());
    $('#lbPrev').addEventListener('click', () => show(gi - 1));
    $('#lbNext').addEventListener('click', () => show(gi + 1));
    lb.addEventListener('click', e => { if (e.target === lb || e.target.classList.contains('lb__img')) lb.close(); });
    lb.addEventListener('keydown', e => { if (e.key === 'ArrowRight') show(gi + 1); if (e.key === 'ArrowLeft') show(gi - 1); });
  }
  const cur = $('#cur');
  function bindZoom(root){
    $$('img[data-zoom]', root).forEach(img => {
      if (img.dataset.bound) return; img.dataset.bound = '1';
      const trigger = img.closest('button') || img;
      if (trigger === img) {
        img.tabIndex = img.closest('.views__stage') && !img.classList.contains('is-on') ? -1 : 0;
        img.setAttribute('role', 'button');
        img.setAttribute('aria-label', 'Ampliar imagen: ' + (img.alt || img.dataset.cap || ''));
        img.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(img); } });
      }
      trigger.addEventListener('click', () => open(img));
      if (fine && cur) { trigger.addEventListener('mouseenter', () => cur.classList.add('is-on')); trigger.addEventListener('mouseleave', () => cur.classList.remove('is-on')); }
    });
  }
  if (fine && cur) addEventListener('mousemove', e => { cur.style.left = e.clientX + 'px'; cur.style.top = e.clientY + 'px'; }, { passive:true });
  bindZoom(document);

  /* Breakpoints: cada pantalla con su tamaño real y una misma escala */
  const dev = $('#bpDevice');
  if (dev) {
    const bp = {
      desk:{ src:'on-desk-1', w:1280, h:650, rad:18, bez:8, note:'Escritorio, 1280 × 650: el computador de administración.', label:'escritorio, 1280 × 650' },
      tabh:{ src:'on-tabh-1', w:1024, h:768, rad:26, bez:14, note:'Tablet horizontal, 1024 × 768: la caja del restaurante.', label:'tablet horizontal, 1024 × 768' },
      tabv:{ src:'on-tabv-1', w:768, h:1024, rad:26, bez:14, note:'Tablet vertical, 768 × 1024: la tablet del mesero en el salón.', label:'tablet vertical, 768 × 1024' },
      mob:{ src:'on-mob-1', w:414, h:750, rad:30, bez:10, note:'Móvil, 414 × 750: el administrador revisa desde cualquier lugar.', label:'móvil, 414 × 750' }
    };
    Object.values(bp).forEach(v => { const i = new Image(); i.src = IMG + v.src + '.webp'; });
    const stage = dev.parentElement, bpImg = $('#bpImg');
    let cur = bp.desk;
    const fit = () => {
      const cs = getComputedStyle(stage);
      const W = stage.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight) - 40;
      const H = Math.min(innerHeight * 0.72, 720);
      const s = Math.min(W / 1308, H / 1052, 1); /* la escala sale del dispositivo más ancho y del más alto */
      dev.style.setProperty('--sw', (cur.w * s).toFixed(1) + 'px');
      dev.style.setProperty('--sh', (cur.h * s).toFixed(1) + 'px');
      dev.style.setProperty('--rad', cur.rad); dev.style.setProperty('--bez', Math.max(4, Math.round(cur.bez * Math.max(s, .5))));
      stage.style.minHeight = (1052 * s + 80) + 'px';
    };
    addEventListener('resize', fit); fit();
    $$('[data-bp]').forEach(btn => btn.addEventListener('click', () => {
      const v = bp[btn.dataset.bp];
      $$('[data-bp]').forEach(b => b.setAttribute('aria-pressed', b === btn));
      bpImg.classList.add('is-swap');
      setTimeout(() => {
        cur = v; fit();
        bpImg.src = IMG + v.src + '.webp'; bpImg.alt = 'Onboarding en ' + v.label; bpImg.setAttribute('aria-label', 'Ampliar imagen: Onboarding en ' + v.label); bpImg.dataset.cap = 'Onboarding en ' + v.label;
        $('#bpNote').textContent = v.note;
        setTimeout(() => bpImg.classList.remove('is-swap'), 280);
      }, reduce ? 0 : 200);
    }));
  }

  /* Puntos de detalle: foco visible, contador y navegación */
  const hsBox = $('.hs');
  if (hsBox) {
    const frame = $('.hs__frame', hsBox), dots = $$('.dot', hsBox), notes = $$('#hsNotes li', hsBox);
    const count = $('#hsCount'), prev = $('#hsPrev'), next = $('#hsNext');
    let cur = 0;
    const set = (i, user) => {
      cur = (i + dots.length) % dots.length;
      const d = dots[cur];
      frame.style.setProperty('--x', d.style.left); frame.style.setProperty('--y', d.style.top);
      dots.forEach((x, k) => { x.setAttribute('aria-pressed', k === cur); x.classList.toggle('is-seen', x.classList.contains('is-seen') || k === cur); });
      notes.forEach((n, k) => n.classList.toggle('is-on', k === cur));
      if (count) count.textContent = (cur + 1) + ' de ' + dots.length;
      if (user) hsBox.classList.add('is-used');
    };
    dots.forEach((d, k) => d.addEventListener('click', () => set(k, true)));
    notes.forEach((n, k) => n.addEventListener('click', () => set(k, true)));
    prev && prev.addEventListener('click', () => set(cur - 1, true));
    next && next.addEventListener('click', () => set(cur + 1, true));
    set(0, false);
  }

  /* Flujos (carruseles) */
  const renderTrack = (track, items, grp) => {
    track.innerHTML = items.map(([f, t], i) => `<figure class="flow__item"><button type="button" aria-label="Ampliar paso ${i+1}: ${t}"><img src="${IMG}${f}.webp" alt="Paso ${i+1}: ${t}" data-zoom data-group="${grp}" data-cap="Paso ${i+1}. ${t}" loading="lazy"></button><figcaption><span class="num">${String(i+1).padStart(2,'0')}</span><span>${t}</span></figcaption></figure>`).join('');
    track.scrollLeft = 0; bindZoom(track);
  };
  $$('[data-flow-json]').forEach(track => {
    const data = JSON.parse(track.dataset.flowJson);
    const grp = track.id;
    const sw = $$(`[data-flow-for="${track.id}"]`);
    const sec = track.closest('.flow');
    const set = k => { sw.forEach(b => b.setAttribute('aria-pressed', b.dataset.flowKey === k)); if (sec) sec.classList.toggle('is-desk', k === 'd'); renderTrack(track, data[k], grp); };
    sw.forEach(b => b.addEventListener('click', () => set(b.dataset.flowKey)));
    set(Object.keys(data)[0]);
  });
  $$('[data-scroll]').forEach(b => b.addEventListener('click', () => {
    const t = document.getElementById(b.dataset.scroll), it = t.querySelector('.flow__item');
    if (it) t.scrollBy({ left: +b.dataset.dir * (it.offsetWidth + 18), behavior: reduce ? 'auto' : 'smooth' });
  }));

  /* Card sorting */
  const board = $('#sortBoard');
  if (board) {
    const btn = $('#sortBtn'), note = $('#sortNote');
    const groups = JSON.parse(board.dataset.groups), cards = [];
    groups.forEach(([g, list], k) => list.forEach(t => { const c = document.createElement('span'); c.className = 'card'; c.textContent = t; c.dataset.g = k; cards.push(c); }));
    const mixed = [5,0,12,8,3,14,1,10,6,13,2,9,4,11,7].map(i => cards[i]);
    let grouped = false;
    const layout = toG => {
      const first = new Map(cards.map(c => [c, c.getBoundingClientRect()]));
      board.innerHTML = ''; board.className = 'sort__board ' + (toG ? 'is-grouped' : 'is-mixed');
      if (toG) groups.forEach(([g, list], k) => { const col = document.createElement('div'); col.className = 'sort__col'; col.innerHTML = `<h4>${g}<span>${list.length} funciones</span></h4>`; cards.filter(c => c.dataset.g == k).forEach(c => col.appendChild(c)); board.appendChild(col); });
      else mixed.forEach(c => board.appendChild(c));
      if (reduce || !first.get(cards[0]).width) return;
      cards.forEach((c, i) => { const a = first.get(c), b = c.getBoundingClientRect(); c.animate([{ transform:`translate(${a.left-b.left}px,${a.top-b.top}px)` }, { transform:'none' }], { duration:700, delay:i*18, easing:'cubic-bezier(.2,.7,.1,1)', fill:'backwards' }); });
    };
    layout(false);
    btn.addEventListener('click', () => { grouped = !grouped; layout(grouped); btn.textContent = grouped ? 'Mezclar tarjetas' : 'Agrupar tarjetas'; btn.setAttribute('aria-pressed', grouped); note.textContent = grouped ? '4 grupos: así quedó la navegación' : '15 tarjetas sin ordenar'; });
  }

  /* Antes / después */
  const ba = $('#baFrame');
  if (ba) {
    const r = $('#baRange');
    const set = v => { v = Math.max(0, Math.min(100, v)); ba.style.setProperty('--p', v + '%'); r.value = v; };
    let on = false;
    const at = e => { const b = ba.getBoundingClientRect(); set((e.clientX - b.left) / b.width * 100); };
    ba.addEventListener('pointerdown', e => { on = true; ba.setPointerCapture(e.pointerId); at(e); });
    ba.addEventListener('pointermove', e => { if (on) at(e); });
    ba.addEventListener('pointerup', () => on = false);
    ba.addEventListener('pointercancel', () => on = false);
    r.addEventListener('input', () => set(+r.value));
  }

  /* Navegador con scroll: recorrer la página */
  $$('[data-tour]').forEach(btn => {
    const view = document.getElementById(btn.dataset.tour);
    let raf = null;
    btn.addEventListener('click', () => {
      cancelAnimationFrame(raf);
      const max = view.scrollHeight - view.clientHeight;
      if (view.scrollTop >= max - 4) { view.scrollTo({ top:0, behavior: reduce ? 'auto' : 'smooth' }); btn.textContent = 'Recorrer la página'; return; }
      if (reduce) { view.scrollTop = max; return; }
      const from = view.scrollTop, t0 = performance.now(), D = Math.max(2500, (max - from) * 2.2);
      btn.textContent = 'Detener';
      const step = now => { const t = Math.min(1, (now - t0) / D); view.scrollTop = from + (max - from) * (t < .5 ? 2*t*t : 1 - Math.pow(-2*t + 2, 2) / 2); if (t < 1 && btn.textContent === 'Detener') raf = requestAnimationFrame(step); else btn.textContent = view.scrollTop >= max - 4 ? 'Volver arriba' : 'Recorrer la página'; };
      raf = requestAnimationFrame(step);
      btn.onclick = null;
    });
    view.addEventListener('wheel', () => { cancelAnimationFrame(raf); if (btn.textContent === 'Detener') btn.textContent = 'Recorrer la página'; }, { passive:true });
  });

  /* Vistas con pestañas */
  $$('[data-views]').forEach(box => {
    const btns = $$('button[data-view]', box), imgs = $$('.views__stage img', box);
    btns.forEach(b => b.addEventListener('click', () => {
      btns.forEach(x => x.setAttribute('aria-pressed', x === b));
      imgs.forEach(im => { const on = im.dataset.view === b.dataset.view; im.classList.toggle('is-on', on); im.tabIndex = on ? 0 : -1; });
    }));
  });

  /* Copiar correo */
  const mailBtn = $('#mailBtn'), toast = $('#toast');
  if (mailBtn) {
    const say = m => { toast.textContent = m; toast.classList.add('is-on'); clearTimeout(say.t); say.t = setTimeout(() => toast.classList.remove('is-on'), 2200); };
    mailBtn.addEventListener('click', () => {
      const addr = 'norbertosc19@gmail.com';
      const fb = () => { const r = document.createRange(); r.selectNodeContents($('.mail__addr')); const s = getSelection(); s.removeAllRanges(); s.addRange(r); say('Correo seleccionado, cópialo con Ctrl/Cmd + C'); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(addr).then(() => { say('Correo copiado'); $('#mailHint').textContent = 'Copiado'; }).catch(fb); else fb();
    });
  }

  /* Prototipos: estados, hotspots, overlays y temporizadores recreados desde Figma */
  $$('[data-proto]').forEach(box => {
    const P = JSON.parse(box.dataset.proto);
    const stage = $('.proto__stage', box);
    const pc = (v, t) => (v / t * 100) + '%';
    const states = {}, ovs = {};
    Object.entries(P.states).forEach(([id, st]) => {
      const im = document.createElement('img');
      im.className = 'proto__state'; im.src = IMG + st.src + '.webp'; im.alt = st.alt; im.dataset.state = id; im.loading = 'lazy';
      stage.appendChild(im); states[id] = im;
    });
    Object.entries(P.ovs || {}).forEach(([id, o]) => {
      const w = document.createElement('div');
      w.className = 'proto__ov'; w.dataset.ov = id;
      w.style.cssText = `left:${pc(o.box[0], P.w)};top:${pc(o.box[1], P.h)};width:${pc(o.box[2], P.w)};height:${pc(o.box[3], P.h)}`;
      w.innerHTML = `<img src="${IMG}${o.src}.webp" alt="${o.alt}" loading="lazy">`;
      stage.appendChild(w); ovs[id] = w;
    });
    const hint = $('.proto__hint', box), log = $('.proto__log', box);
    let cur = P.start, openOv = null, timers = [];
    const say = t => { if (log) { log.textContent = t; log.classList.remove('is-new'); void log.offsetWidth; log.classList.add('is-new'); } };
    const dur = ms => reduce ? 0 : ms;
    const show = (id, ms, ease) => {
      if (!states[id]) return;
      Object.values(states).forEach(im => { im.style.transitionDuration = dur(ms || 300) + 'ms'; im.style.transitionTimingFunction = ease || 'cubic-bezier(.2,.7,.1,1)'; });
      states[cur] && states[cur].classList.remove('is-on');
      states[id].classList.add('is-on'); cur = id;
      $$('.proto__hs', stage).forEach(h => h.hidden = !(h.dataset.on.split(' ').includes(cur) || h.dataset.on === '*') || (h.dataset.inov && h.dataset.inov !== openOv));
      schedule();
    };
    const toggleOv = (id, ms, force) => {
      const open = force !== undefined ? force : openOv !== id;
      Object.entries(ovs).forEach(([k, o]) => { o.style.transitionDuration = dur(ms || 300) + 'ms'; o.classList.toggle('is-on', open && k === id); });
      openOv = open ? id : null;
      $$('.proto__hs', stage).forEach(h => {
        if (h.dataset.inov) h.hidden = h.dataset.inov !== openOv;
        else h.hidden = !!openOv && P.modal || !(h.dataset.on.split(' ').includes(cur) || h.dataset.on === '*');
      });
    };
    const schedule = () => {
      timers.forEach(clearTimeout); timers = [];
      const a = (P.after || {})[cur];
      if (a && box.classList.contains('is-live')) timers.push(setTimeout(() => { if (a.ov) toggleOv(a.ov, a.ms, true); else show(a.go, a.ms, a.ease); if (a.say) say(a.say); }, a.wait));
    };
    (P.hs || []).forEach(h => {
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'proto__hs' + (h.fx ? ' proto__hs--' + h.fx : '');
      b.dataset.on = h.on; if (h.inov) b.dataset.inov = h.inov;
      b.style.cssText = `left:${pc(h.box[0], P.w)};top:${pc(h.box[1], P.h)};width:${pc(h.box[2], P.w)};height:${pc(h.box[3], P.h)}`;
      b.setAttribute('aria-label', h.label);
      if (h.text) b.innerHTML = `<span>${h.text}</span>`;
      if (h.img) b.innerHTML = `<img src="${IMG}${h.img}.webp" alt="" loading="lazy">`;
      const act = () => {
        if (h.go) show(h.go, h.ms, h.ease);
        if (h.ov) toggleOv(h.ov, h.ms);
        if (h.close) toggleOv(openOv, h.ms, false);
        if (h.say) say(h.say);
        box.classList.add('is-used');
      };
      if (h.trig === 'hover') {
        b.addEventListener('mouseenter', () => { b.classList.add('is-hover'); if (h.say) say(h.say); box.classList.add('is-used'); });
        b.addEventListener('mouseleave', () => b.classList.remove('is-hover'));
        b.addEventListener('focus', () => b.classList.add('is-hover'));
        b.addEventListener('blur', () => b.classList.remove('is-hover'));
        b.addEventListener('click', () => { const on = !b.classList.contains('is-hover') || !fine; $$('.proto__hs.is-hover', stage).forEach(x => x !== b && x.classList.remove('is-hover')); b.classList.toggle('is-hover', on); if (h.say) say(h.say); box.classList.add('is-used'); });
      } else b.addEventListener('click', act);
      stage.appendChild(b);
    });
    /* clic fuera de un hotspot: destella las zonas, como en el modo presentación de Figma */
    stage.addEventListener('click', e => {
      if (e.target.closest('.proto__hs')) return;
      if (openOv && P.closeOutside !== false) { toggleOv(openOv, 300, false); return; }
      box.classList.remove('is-flash'); void box.offsetWidth; box.classList.add('is-flash');
    });
    const reset = $('.proto__reset', box);
    reset && reset.addEventListener('click', () => { toggleOv(openOv, 0, false); show(P.start, 0); say(P.intro || ''); });
    const tg = $('.proto__zones', box);
    tg && tg.addEventListener('click', () => { const on = box.classList.toggle('show-zones'); tg.setAttribute('aria-pressed', on); });
    states[P.start].classList.add('is-on');
    show(P.start, 0);
    /* los temporizadores arrancan cuando el prototipo entra en pantalla */
    new IntersectionObserver((es, ob) => es.forEach(e => { if (e.isIntersecting) { box.classList.add('is-live'); schedule(); ob.disconnect(); } }), { threshold: .45 }).observe(box);
  });
})();
