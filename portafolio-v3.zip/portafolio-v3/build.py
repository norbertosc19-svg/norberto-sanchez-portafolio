#!/usr/bin/env python3
"""Genera index.html y trabajo/*.html del portafolio."""
import json, os, html
ROOT = os.path.dirname(os.path.abspath(__file__))
MAIL = 'norbertosc19@gmail.com'
LI = 'https://www.linkedin.com/in/norbertosanchez'
WA = 'https://wa.me/573113811872'
ARROW_L = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M10 3 5 8l5 5"/></svg>'
ARROW_R = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6"><path d="m6 3 5 5-5 5"/></svg>'
FAV = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='32' fill='%23394A4D'/%3E%3Ctext x='32' y='41' font-family='Arial,sans-serif' font-weight='700' font-size='24' text-anchor='middle' fill='%23ECE8E3'%3ENS%3C/text%3E%3C/svg%3E"

# ---------------------------------------------------------------- proyectos
P = [
  dict(slug='onboarding', seo='Onboarding de producto para Precompro', seo_desc='Caso UX/UI: centro de novedades dentro del dashboard de Precompro, diseñado de principio a fin para escritorio, tablet y móvil.', group='precompro', title='Onboarding de producto en el dashboard', year='2023',
       img='on-desk-2', desc='Un centro de novedades que explica cada función nueva sobre la pantalla donde se usa.',
       tags=['Producto SaaS', 'Responsive', 'Handoff']),
  dict(slug='domicilios', seo='Domicilios a la habitación en Precompro', seo_desc='Caso UX/UI de e-commerce: catálogo, carrito y checkout para que los huéspedes pidan a la habitación, en móvil y escritorio.', group='precompro', title='Domicilios para huéspedes de hotel', year='2024',
       img='dom-d1', desc='Catálogo, carrito y checkout para pedir a la habitación o pagar en línea.',
       tags=['E-commerce', 'Checkout', 'Móvil']),
  dict(slug='planautos', seo='Sitio web de PlanAutos', seo_desc='Caso de diseño web: arquitectura de información, nueve planes de financiación y un simulador de crédito para PlanAutos.', group='ecore', title='PlanAutos, financiación de vehículos', year='2021',
       img='pa-hero', desc='Sitio con nueve planes de crédito y un simulador para calcular la cuota.',
       tags=['Sitio web', 'Finanzas', 'Simulador']),
  dict(slug='fairplay', seo='Sitio web de Fairplay', seo_desc='Caso de diseño web para una fintech de e-commerce en México, diseñado a partir de un guion de UX writing.', group='ecore', title='Fairplay, capital para e-commerce', year='2021',
       img='fp-hero', desc='Sitio de una fintech mexicana pensado para generar leads y pruebas del simulador.',
       tags=['Sitio web', 'Fintech', 'UX writing']),
  dict(slug='archlight', seo='Sitio web de Arch Light', seo_desc='Caso de diseño web para un estudio de fotografía de arquitectura: composición, grilla de proyectos y galería.', group='ecore', title='Arch Light, fotografía de arquitectura', year='2022',
       img='al-home', desc='Portafolio minimalista donde la fotografía ocupa toda la pantalla.',
       tags=['Sitio web', 'Portafolio', 'Galería']),
  dict(slug='chicacuantica', seo='Sitio web de Chica Cuántica', seo_desc='Caso de diseño web para un proyecto de astrología y coaching: servicios, talleres, tienda y blog, con microinteracciones diseñadas en Figma.', group='ecore', title='Chica Cuántica, astrología y coaching', year='2021',
       img='cc-hero-b', desc='Sitio con servicios, talleres, tienda y blog, y microinteracciones en cada sección.',
       tags=['Sitio web', 'Bienestar', 'Microinteracciones']),
  dict(slug='fraternidad', seo='App Fraternidad, prueba técnica UI', seo_desc='Prueba técnica de diseño UI: app móvil para el personal de enfermería de un hogar geriátrico, con guía de estilo y UI kit.', group='fraternidad', title='App para el cuidado de adultos mayores', year='Prueba técnica',
       img='frat-home-o', desc='Seguimiento de cada paciente en el turno de enfermería, con guía de estilo y UI kit.',
       tags=['App móvil', 'Salud', 'UI kit']),
  dict(slug='huellas-unidas', seo='Huellas Unidas, app nativa de Coderhouse', seo_desc='Proyecto académico en curso: app para reportar mascotas perdidas, con entrevistas, encuestas, card sorting, arquitectura de información, wireframes, moodboard y UI kit.', group='coderhouse', title='Huellas Unidas, reporte de mascotas perdidas', year='2026',
       img='hu-hero', desc='App nativa para reportar una mascota perdida en tres pasos, del card sorting al diseño visual.',
       tags=['App nativa', 'Arquitectura de información', 'En curso']),
]
BY = {p['slug']: p for p in P}
GROUPS = [
  ('precompro', 'Precompro', 'Único diseñador de producto, 2022 – 2025'),
  ('ecore', 'e-Core Digital Performance', 'Diseñador web UX/UI en agencia, 2021 – 2022'),
  ('fraternidad', 'Fraternidad', 'Prueba técnica de diseño UI'),
  ('coderhouse', 'Coderhouse', 'Proyecto académico en curso, 2026'),
]
GNAME = {g[0]: g[1] for g in GROUPS}

# ---------------------------------------------------------------- piezas comunes
# Dominio definitivo del portafolio. Cuando se conozca (por ejemplo https://norbertosanchez.com/),
# escríbelo aquí y se generan la URL canónica, og:url y rutas absolutas para la imagen al compartir.
SITE_URL = 'https://norberto-sanchez-portafolio.vercel.app/'

def head(title, desc, pre, path='', og_img=None, extra=''):
    og = f'assets/og/{og_img}.jpg' if og_img else 'assets/og-portafolio.jpg'
    if SITE_URL:
        canon = f'<link rel="canonical" href="{SITE_URL}{path}">\n<meta property="og:url" content="{SITE_URL}{path}">\n'
        og_abs = SITE_URL + og
    else:
        canon = ''
        og_abs = pre + og
    return f'''<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{title}</title>
<meta name="claude:viewport-fit-sides" content="cover">
<meta name="description" content="{html.escape(desc)}">
<meta name="author" content="Norberto Sánchez Cañón">
<meta name="theme-color" content="#394A4D">
{canon}<meta property="og:type" content="website">
<meta property="og:locale" content="es_CO">
<meta property="og:site_name" content="Norberto Sánchez Cañón, UI/UX Designer">
<meta property="og:title" content="{html.escape(title)}">
<meta property="og:description" content="{html.escape(desc)}">
<meta property="og:image" content="{og_abs}">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="{html.escape(title)}">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="{FAV}">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap">
<link rel="stylesheet" href="{pre}assets/css/base.css">
<link rel="stylesheet" href="{pre}assets/css/extra.css">
{extra}</head>
'''

def chrome(pre, home):
    h = '' if home else f'{pre}index.html'
    cv = f'{pre}assets/Norberto_Sanchez_Canon_CV.pdf'
    return f'''<a class="skip" href="#main">Saltar al contenido</a>

<header class="top" id="top">
  <div class="wrap top__in">
    <a class="brand" href="{h or '#inicio'}" aria-label="Norberto Sánchez, inicio"><span class="brand__mark" aria-hidden="true">NS</span><span>Norberto Sánchez</span></a>
    <nav class="nav" aria-label="Principal">
      <a href="{h}#proyectos">Proyectos</a>
      <a href="{h}#sobre-mi">Sobre mí</a>
      <a href="{h}#contacto">Contacto</a>
      <a class="nav__cv" href="{cv}" target="_blank" rel="noopener">CV en PDF</a>
    </nav>
    <button class="menu-btn" type="button" aria-expanded="false" aria-controls="menu" id="menuBtn">Menú</button>
  </div>
</header>

<div class="overlay" id="menu" role="dialog" aria-modal="true" aria-label="Menú">
  <div class="overlay__head">
    <span class="brand"><span class="brand__mark" aria-hidden="true" style="background:var(--mantel);color:var(--carbon)">NS</span>Norberto Sánchez</span>
    <button class="menu-btn" type="button" id="menuClose" style="display:inline-flex">Cerrar</button>
  </div>
  <nav aria-label="Menú móvil">
    <a href="{h}#proyectos">Proyectos</a>
    <a href="{h}#sobre-mi">Sobre mí</a>
    <a href="{h}#contacto">Contacto</a>
    <a href="{cv}" target="_blank" rel="noopener">CV en PDF</a>
  </nav>
  <div class="overlay__foot">
    <span>{MAIL}</span>
    <a href="{LI}" target="_blank" rel="noopener">LinkedIn</a>
    <a href="{WA}" target="_blank" rel="noopener">WhatsApp</a>
  </div>
</div>
'''

def tail(pre):
    return f'''
<div class="cur" id="cur" aria-hidden="true">Ampliar</div>
<div class="toast" id="toast" role="status" aria-live="polite"></div>
<dialog class="lb" id="lb" aria-label="Imagen ampliada">
  <div class="lb__bar"><span id="lbCap"></span><button type="button" id="lbClose">Cerrar</button></div>
  <div class="lb__img"><img id="lbImg" alt=""></div>
  <div class="lb__foot"><button type="button" id="lbPrev">Anterior</button><button type="button" id="lbNext">Siguiente</button></div>
</dialog>
<script src="{pre}assets/js/site.js"></script>
</body>
</html>
'''

def tags(ts):
    return '<ul class="tags">' + ''.join(f'<li>{t}</li>' for t in ts) + '</ul>'

def flow(tid, kind, title, data, hint, switch=None):
    sw = ''
    if switch:
        sw = '<div class="seg" role="group" aria-label="Versión del flujo">' + ''.join(
            f'<button type="button" aria-pressed="{"true" if i == 0 else "false"}" data-flow-for="{tid}" data-flow-key="{k}">{lab}</button>'
            for i, (k, lab) in enumerate(switch)) + '</div>'
    js = html.escape(json.dumps(data, ensure_ascii=False), quote=True)
    return f'''<section class="flow flow--{kind}" aria-labelledby="{tid}T">
      <div class="flow__top"><h2 class="h-s" id="{tid}T">{title}</h2>{sw}</div>
      <div class="flow__track" id="{tid}" tabindex="0" aria-label="{title}" data-flow-json="{js}"></div>
      <div class="flow__top" style="margin:8px 0 0">
        <span class="flow__hint">{hint}</span>
        <div class="flow__nav">
          <button type="button" data-scroll="{tid}" data-dir="-1" aria-label="Pantalla anterior">{ARROW_L}</button>
          <button type="button" data-scroll="{tid}" data-dir="1" aria-label="Pantalla siguiente">{ARROW_R}</button>
        </div>
      </div>
    </section>'''

def body(title, inner):
    return f'''<div class="case__body">
      <h2 class="h-s">{title}</h2>
      <div class="prose">{inner}</div>
    </div>'''

def browser(vid, url, img, w, h, alt, note):
    return f'''<div class="browser">
      <div class="browser__bar"><i></i><i></i><i></i><span>{url}</span></div>
      <div class="browser__view" id="{vid}" tabindex="0" aria-label="{alt}, desplázate para recorrerla">
        <img src="../assets/img/{img}.webp" width="{w}" height="{h}" alt="{alt}" loading="lazy">
      </div>
    </div>
    <div class="browser__foot"><span>{note}</span><button type="button" class="btn" data-tour="{vid}">Recorrer la página</button></div>'''

def shot(img, alt, cap, group=None, w=None, h=None):
    g = f' data-group="{group}"' if group else ''
    wh = f' width="{w}" height="{h}"' if w else ''
    return f'<figure class="shot"><button type="button" aria-label="Ampliar: {alt}"><img src="../assets/img/{img}.webp"{wh} alt="{alt}" data-zoom{g} data-cap="{cap}" loading="lazy"></button><figcaption>{cap}</figcaption></figure>'

def decisions(items):
    out = '<div class="decisions">'
    for img, alt, h, p in items:
        out += f'''
      <div class="decision">
        <button type="button" aria-label="Ampliar: {alt}"><img src="../assets/img/{img}.webp" alt="{alt}" data-zoom data-cap="{alt}" loading="lazy"></button>
        <div><h3>{h}</h3><p>{p}</p></div>
      </div>'''
    return out + '\n    </div>'

def steps(items):
    return '<ol class="steps">' + ''.join(f'<li><div><strong>{a}</strong><span>{b}</span></div></li>' for a, b in items) + '</ol>'

def gallery(items, group):
    return '<div class="gallery">' + ''.join(
        f'<button type="button"><figure style="margin:0"><img src="../assets/img/{i}.webp" alt="{a}" data-zoom data-group="{group}" data-cap="{a}" loading="lazy"><figcaption>{c}</figcaption></figure></button>'
        for i, a, c in items) + '</div>'

ORDER = [p['slug'] for p in P]

def page(slug, kicker, h1, lede, meta, brief, content, tones=('mantel',), note=None):
    p = BY[slug]
    nxt = BY[ORDER[(ORDER.index(slug) + 1) % len(ORDER)]]
    meta_html = ''.join(f'<div><dt>{a}</dt><dd>{b}</dd></div>' for a, b in meta)
    brief_html = ''.join(f'<div><dt>{a}</dt><dd>{b}</dd></div>' for a, b in brief)
    note_html = f'<p class="pnote">{note}</p>' if note else ''
    parts = content if isinstance(content, list) else [content]
    arts = ''
    for i, c in enumerate(parts):
        tone = tones[i % len(tones)]
        arts += f'\n<section class="case" data-tone="{tone}">\n  <div class="wrap">\n    {c}\n  </div>\n</section>\n'
    doc = head(f'{p["seo"]} | Norberto Sánchez, UI/UX Designer', p['seo_desc'], '../', f'trabajo/{slug}.html', p['img'])
    doc += '<body data-tone="pizarra" data-img="../assets/img/">\n' + chrome('../', False)
    doc += f'''
<main id="main" tabindex="-1">
<section class="phead" data-tone="pizarra">
  <div class="wrap">
    <nav class="crumbs" aria-label="Ruta de navegación"><a href="../index.html#proyectos">Proyectos</a><span aria-hidden="true">/</span><span>{GNAME[p['group']]}</span></nav>
    <div class="case__head" style="margin:0">
      <div>
        <p class="case__kicker">{kicker}</p>
        <h1 class="h-m">{h1}</h1>
        <p class="lede" style="margin-top:20px">{lede}</p>
        {note_html}
        {tags(p['tags'])}
      </div>
      <dl class="meta">{meta_html}</dl>
    </div>
    <dl class="brief" aria-label="Resumen del caso">{brief_html}</dl>
  </div>
</section>
{arts}
<section class="next" data-tone="carbon">
  <div class="wrap">
    <div class="next__in">
      <a class="next__link" href="{nxt['slug']}.html"><small>Siguiente proyecto: {GNAME[nxt['group']]}</small><span class="h-m">{nxt['title']}</span></a>
      <a class="btn" href="../index.html#proyectos">Todos los proyectos</a>
    </div>
    <footer class="foot">
      <span>¿Hablamos? {MAIL}</span>
      <a href="../index.html#contacto">Contacto</a>
    </footer>
  </div>
</section>
</main>
'''
    doc += tail('../')
    os.makedirs(os.path.join(ROOT, 'trabajo'), exist_ok=True)
    with open(os.path.join(ROOT, 'trabajo', slug + '.html'), 'w') as f:
        f.write(doc)

NO_METRICS = 'No tuve acceso a métricas de uso: en Precompro las cifras las manejaba otra área.'

# ================================================================ ONBOARDING
page('onboarding', 'Precompro · Onboarding de producto',
  'Que los restaurantes se enteren de lo nuevo sin salir del dashboard',
  'Precompro lanzaba funciones nuevas con frecuencia, pero los equipos de los restaurantes no se enteraban. Diseñé un centro de novedades que explica cada mejora en la misma pantalla donde se usa.',
  [('Mi rol', 'Único diseñador de producto. Diseño de principio a fin, del flujo al seguimiento de la implementación'), ('Pantallas', 'Escritorio, tablet horizontal, tablet vertical y móvil'), ('Herramientas', 'Figma, Jira'), ('Estado', 'Entregado e implementado')],
  [('Problema', 'Las funciones nuevas pasaban desapercibidas para quienes usan el dashboard todos los días.'),
   ('Mi aporte', 'Flujo, wireframes, interfaces, prototipo, adaptación a cuatro pantallas y handoff en Jira.'),
   ('Resultado', 'Entregado e implementado. ' + NO_METRICS)],
  [f'''<figure class="pill" data-pill>
      <div class="pill__clip"><img src="../assets/img/on-desk-1.webp" width="1280" height="650" alt="Modal ¡Conoce lo nuevo! abierto sobre el plano de mesas del dashboard de Precompro" data-zoom data-group="onb" data-cap="Modal de bienvenida sobre el dashboard"></div>
      <figcaption>El centro de novedades se abre sobre la pantalla que el equipo usa todo el día.</figcaption>
    </figure>
    {body('Contexto', '<p>Precompro es un software de reservas, pedidos y gestión para restaurantes. El equipo de cada restaurante trabaja en el dashboard durante todo el turno: en la caja, en la tablet del salón y en el computador de administración.</p>')}
    {body('Problema', '<p>Cada vez que salía una función nueva, el restaurante no se enteraba o no sabía dónde encontrarla. Para Precompro, una mejora que nadie conoce no llega a usarse. Hacía falta anunciar las novedades dentro de la plataforma, en el momento en que el colaborador las iba a necesitar y sin sacarlo de su trabajo.</p>')}
    {body('Mi rol', '<p>Era el único diseñador de producto, así que el proceso de diseño estuvo a mi cargo de principio a fin. Definí cómo se presentaban las novedades, hice los wireframes y las interfaces, armé el prototipo, adapté la solución a cada tamaño de pantalla y preparé la entrega para el equipo de desarrollo.</p>')}
    <div class="case__body">
      <h2 class="h-s">Proceso</h2>
      {steps([('Flujo y wireframes', 'Del ingreso al centro de novedades hasta el cierre del recorrido, en baja fidelidad.'), ('Estructura en tres categorías', 'Lo nuevo, Lo mejorado y Otros servicios, siempre visibles para ubicarse rápido.'), ('Interfaces y prototipo', 'Overlays guiados sobre el dashboard real, prototipados en Figma.'), ('Adaptación responsive', 'Cuatro tamaños de pantalla, para la caja, la tablet del salón y el computador de administración.'), ('Handoff y seguimiento', 'Pantallas y especificaciones en Jira, y seguimiento con desarrollo hasta la implementación.')])}
    </div>''',
   f'''<section class="bp" aria-labelledby="bpT">
      <div class="case__body" style="margin-top:0">
        <h2 class="h-s" id="bpT">Solución en cuatro pantallas</h2>
        <p class="prose">En un restaurante nadie usa un solo dispositivo. Cambia de tamaño para ver cómo se adapta la misma pantalla.</p>
      </div>
      <div class="bp__bar" role="group" aria-label="Tamaño de pantalla">
        <button type="button" aria-pressed="true" data-bp="desk">Escritorio <small>1280 × 650</small></button>
        <button type="button" aria-pressed="false" data-bp="tabh">Tablet horizontal <small>1024 × 768</small></button>
        <button type="button" aria-pressed="false" data-bp="tabv">Tablet vertical <small>768 × 1024</small></button>
        <button type="button" aria-pressed="false" data-bp="mob">Móvil <small>414 × 750</small></button>
      </div>
      <div class="bp__stage">
        <div class="bp__device" id="bpDevice" style="--w:1280;--ar:1280/650;--rad:18;--bez:8">
          <img id="bpImg" src="../assets/img/on-desk-1.webp" alt="Onboarding en escritorio, 1280 × 650" data-zoom data-cap="Onboarding en escritorio, 1280 × 650">
        </div>
      </div>
      <p class="bp__note" id="bpNote" aria-live="polite">Escritorio: el computador de administración.</p>
    </section>
    <section class="hs" aria-labelledby="hsT">
      <div class="case__body">
        <h2 class="h-s" id="hsT">Decisiones de diseño</h2>
        <p class="prose">Cuatro decisiones de la sección Lo nuevo. Toca cada número: la imagen se enfoca en esa zona y abajo aparece la explicación.</p>
      </div>
      <div class="hs__frame"><div class="hs__zoom">
        <img src="../assets/img/on-desk-2.webp" width="1280" height="650" alt="Sección Lo nuevo con el módulo Reservar mesa señalado sobre el dashboard" loading="lazy">
        <button class="dot" type="button" style="left:7.2%;top:22%" data-hs="0" aria-pressed="true" aria-label="Detalle 1: categorías">1</button>
        <button class="dot" type="button" style="left:57%;top:43%" data-hs="1" aria-pressed="false" aria-label="Detalle 2: explicación sobre la interfaz">2</button>
        <button class="dot" type="button" style="left:94.6%;top:17%" data-hs="2" aria-pressed="false" aria-label="Detalle 3: etiqueta New">3</button>
        <button class="dot" type="button" style="left:53.3%;top:84.5%" data-hs="3" aria-pressed="false" aria-label="Detalle 4: avance del recorrido">4</button>
      </div></div>
      <div class="hs__ctrl">
        <button type="button" id="hsPrev" aria-label="Detalle anterior">{ARROW_L}</button>
        <span id="hsCount" aria-live="polite">1 de 4</span>
        <button type="button" id="hsNext" aria-label="Detalle siguiente">{ARROW_R}</button>
        <em>Toca un número en la imagen o usa las flechas.</em>
      </div>
      <ol class="hs__notes" id="hsNotes">
        <li class="is-on" data-hs="0"><b>1</b>Tres categorías fijas a la izquierda. El colaborador sabe si ve algo nuevo, una mejora u otro servicio.</li>
        <li data-hs="1"><b>2</b>La novedad se explica sobre la interfaz real, con una flecha que señala dónde está la función.</li>
        <li data-hs="2"><b>3</b>Una etiqueta New marca lo que aún no se ha visto.</li>
        <li data-hs="3"><b>4</b>Puntos de avance y un solo botón para seguir. El recorrido es corto y no interrumpe el trabajo.</li>
      </ol>
    </section>
    {body('Implementación', '<p>Entregué en Jira las pantallas de cada tamaño con sus especificaciones, resolví las dudas del equipo de desarrollo durante la construcción y revisé la implementación hasta que quedó publicada.</p>')}
    {body('Resultados', '<p>El centro de novedades se implementó en la plataforma. No tuve acceso a las métricas posteriores al lanzamiento, ya que su seguimiento estaba a cargo de otra área. Por eso, el caso documenta principalmente las decisiones de diseño, la solución entregada y su implementación.</p>')}
    {gallery([('on-desk-23', 'Lo nuevo: campañas de marketing', 'Lo nuevo: marketing'), ('on-desk-3', 'Lo mejorado: descarga de encuestas', 'Lo mejorado: encuestas'), ('on-desk-4', 'Otros servicios: domicilios e integraciones', 'Otros servicios: domicilios')], 'onb')}'''],
  tones=('mantel', 'bruma'))

# ================================================================ DOMICILIOS
DOM = {
  'm': [['dom-m1','Elige una categoría'],['dom-m23','Explora los platos'],['dom-m232','Revisa el detalle'],['dom-m4','Ajusta tu orden'],['dom-m41','Confirma antes de eliminar'],['dom-m5','Datos de entrega'],['dom-m61','Paga o carga a la habitación'],['dom-m7','Pedido confirmado']],
  'd': [['dom-d1','Elige una categoría'],['dom-d3','Explora los platos'],['dom-d31','Revisa el detalle'],['dom-d41','Ajusta tu orden'],['dom-d42','Confirma antes de eliminar'],['dom-d5','Datos de entrega y pago'],['dom-d6','Pedido confirmado']]}
page('domicilios', 'Precompro · Domicilios a la habitación',
  'Pedir a la habitación sin llamar a recepción',
  'Un restaurante ubicado dentro de un hotel de gran tamaño necesitaba que los huéspedes pidieran comida, bebidas, snacks e incluso almohadas desde el celular, sin pasar por recepción y sin perder el control de lo que se consume en cada habitación.',
  [('Mi rol', 'Diseño UI/UX del flujo de compra completo: catálogo, carrito y checkout'), ('Pantallas', 'Móvil, tablet y escritorio'), ('Herramientas', 'Figma, Jira'), ('Estado', 'Entregado e implementado')],
  [('Problema', 'Los pedidos a la habitación dependían de recepción y había que respetar la facturación del hotel.'),
   ('Mi aporte', 'Flujo de e-commerce de punta a punta en móvil, tablet y escritorio, con dos formas de pago.'),
   ('Resultado', 'Entregado e implementado. ' + NO_METRICS)],
  [f'''<figure class="pill" data-pill>
      <div class="pill__clip"><img src="../assets/img/dom-d1.webp" width="1600" height="900" alt="Home del catálogo con las categorías Restaurante, Bebidas, Snacks y Carta de almohadas" data-zoom data-cap="Home del catálogo de domicilios"></div>
      <figcaption>Cuatro entradas: restaurante, bebidas, snacks y una carta de almohadas.</figcaption>
    </figure>
    {body('Contexto', '<p>Precompro Domicilios es la experiencia de pedidos en línea de la plataforma para restaurantes. Este fue un caso puntual: un restaurante que funciona dentro de un hotel. Quien compra es un huésped que está en su habitación, muchas veces desde el celular y sin conocer la carta.</p>')}
    {body('Problema', '<p>Pedir algo a la habitación significaba llamar a recepción. El restaurante quería que el huésped pidiera solo, pero con una condición de negocio: lo que se carga a la habitación tiene que conciliarse y pagarse en el checkout del hotel.</p>')}
    {body('Mi rol', '<p>Diseñé el flujo completo de compra, del catálogo a la confirmación del pedido, en versiones para móvil, tablet y escritorio, y lo entregué al equipo de desarrollo.</p>')}''',
   f'''{flow('domTrack', 'dom', 'El pedido completo, pantalla por pantalla', DOM, 'Desliza o usa las flechas. Toca una pantalla para ampliarla.', [('m', 'Móvil'), ('d', 'Escritorio')])}
    <div class="case__body">
      <h2 class="h-s">Decisiones de diseño</h2>
      <div class="prose"><p>Cada decisión responde a cómo pide un huésped: desde la cama, con una mano y sin ayuda del personal.</p></div>
    </div>
    {decisions([('dom-m41', 'Confirmación antes de eliminar un producto del carrito', 'Confirmar antes de borrar', 'Quitar un producto pide confirmación. Un toque accidental no deshace un pedido ya armado.'),
                ('dom-m61', 'Pantalla de pago con pago anticipado o cargo a la habitación', 'Dos formas de pagar', 'Pago anticipado con tarjeta o PSE, o cargo directo a la habitación, en la misma pantalla. El huésped elige sin salir del flujo. Mi trabajo fue diseñar cómo se elige y se confirma el pago; la integración técnica con los medios de pago no hizo parte de mi rol.'),
                ('dom-m7', 'Pedido confirmado con número de orden', 'Respetar la regla de facturación', 'Lo cargado a la habitación se concilia y se liquida en el checkout del hotel. La confirmación muestra el número de orden para ese cruce.')])}
    {body('Implementación', '<p>Entregué el flujo a desarrollo con sus versiones para móvil, tablet y escritorio, y acompañé la construcción hasta que quedó implementado.</p>')}
    {body('Resultados', '<p>El flujo se implementó para este restaurante. ' + NO_METRICS + '</p>')}'''],
  tones=('mantel', 'bruma'))

ECORE = f'''<div class="case__body">
      <h2 class="h-s">Proceso con el cliente<span class="h-sub">Así trabajaba con cada cliente de la agencia</span></h2>
      {steps([('Brief', 'Levantaba el brief directamente con el cliente para entender sus objetivos y necesidades.'), ('Ideas en equipo', 'Facilitaba un brainstorming con el equipo interno antes de diseñar.'), ('Arquitectura y diseño', 'Organizaba la arquitectura de información y diseñaba el sitio.'), ('Propuesta con prototipo', 'Presentaba la propuesta con prototipos, interacciones y microinteracciones hechos por mí.'), ('Iteración y handoff', 'Ajustaba con el feedback del cliente, hasta tres rondas, y preparaba los archivos aprobados para desarrollo.')])}
    </div>'''

ECORE_SHORT = '''<div class="case__body">
      <h2 class="h-s">Proceso con el cliente</h2>
      <div class="prose"><p>Seguí el mismo proceso de la agencia que se describe en <a href="planautos.html">PlanAutos</a>: brief con el cliente, ideas en equipo, arquitectura y diseño, propuesta con prototipo e iteración con hasta tres rondas de feedback antes de entregar los archivos a desarrollo.</p></div>
    </div>'''

# ================================================================ PLANAUTOS
SITEMAP = [('Home', 'Propuesta, planes, contacto y blog'), ('Planes', 'Nueve planes con una misma plantilla'), ('Simulador de crédito', 'Acceso fijo en el encabezado'), ('Paga en línea', 'Acceso fijo en el encabezado'), ('Sedes', 'Mapa con oficinas'), ('Nosotros, preguntas y contacto', 'Información de apoyo')]
page('planautos', 'e-Core · Sitio web para PlanAutos',
  'Nueve planes de crédito, una sola pregunta: cuánto pago al mes',
  'PlanAutos financia vehículos para clientes de concesionarios. El sitio tenía que presentar nueve planes distintos sin confundir y llevar a cada visitante a simular su crédito o a hablar con un asesor.',
  [('Mi rol', 'Arquitectura de información y diseño web del sitio'), ('Cliente', 'PlanAutos, a través de la agencia e-Core'), ('Pantallas', 'Escritorio'), ('Herramientas', 'Figma')],
  [('Problema', 'Mucha información financiera y nueve planes que el visitante tenía que entender rápido.'),
   ('Mi aporte', 'Organización del contenido, jerarquía de la home, plantilla de planes, simulador y páginas de apoyo.'),
   ('Resultado', 'El sitio se publicó. No tengo datos de uso ni de conversión.')],
  [f'''{browser('paView', 'PlanAutos, home', 'pa-home', 1440, 3350, 'Home de PlanAutos', 'La home completa: slider, planes, formulario de contacto, blog y footer.')}
    {body('Contexto', '<p>PlanAutos era cliente de e-Core, la agencia de marketing digital donde trabajé como diseñador web. Ofrece varios planes de financiación para comprar vehículo, cada uno con condiciones distintas.</p>')}
    {body('Problema', '<p>Nueve planes con nombres propios, tasas y condiciones son mucha información para alguien que solo quiere saber si le alcanza. El sitio tenía que ordenar ese contenido y llevar al visitante a dos acciones: simular su crédito o dejar sus datos para un asesor.</p>')}
    {body('Mi rol', '<p>Organicé la arquitectura de información del sitio y diseñé cada página: home, plantilla de planes, simulador, sedes, nosotros, preguntas frecuentes y contacto.</p>')}
    {ECORE}''',
   f'''<div class="case__body" style="margin-top:0">
      <h2 class="h-s">Arquitectura de información</h2>
      <div>
        <p class="prose">Las tareas que más repite un cliente, simular y pagar, quedaron fijas en el encabezado de todas las páginas. El resto del contenido se ordena de lo general a lo específico.</p>
        <ul class="smap">{''.join(f'<li><b>{a}</b><span>{b}</span></li>' for a, b in SITEMAP)}</ul>
      </div>
    </div>
    {body('Jerarquía de la home', '<p>La home presenta la propuesta, «Financiación a la medida», y enseguida los planes. Después vienen el formulario «Comunícate con nosotros» y el blog. Quien llega sabe primero qué ofrece PlanAutos y luego qué puede hacer.</p>')}
    <div class="case__body">
      <h2 class="h-s">Un simulador en lugar de una tabla</h2>
      <div class="prose"><p>En vez de explicar tasas, el simulador responde la pregunta real. Se elige condición y modelo, se escribe el precio y la cuota inicial, y se toca un plazo de 12 a 84 meses. La cuota mensual aparece antes del botón Solicita tu crédito.</p></div>
    </div>
    <div class="duo">
      {shot('pa-planes', 'Páginas de los planes de financiación', 'Los nueve planes comparten una plantilla: tradicional, flexiplan, premium, menos dos, me cuido, extra, por partes, total cien y super.', 'pa', 1185, 2000)}
      {shot('pa-simulador', 'Modal Calcula tu crédito con campos y plazos', 'Simulador: los plazos son botones de un toque, no un campo para escribir.', 'pa', 528, 656)}
    </div>''',
   f'''<div class="duo" style="margin-top:0">
      {shot('pa-sedes', 'Página de sedes con mapa de oficinas', 'Sedes en Bogotá y Montería sobre un mapa, con dirección y horario.', 'pa', 816, 1800)}
      <div class="prose">
        <h2 class="h-s" style="margin-bottom:16px">Un lenguaje visual propio</h2>
        <p>Los cortes diagonales de las fotografías se repiten en el slider, en los bloques de los planes y en los botones del simulador. Le dan unidad a un sitio con muchas páginas y lo diferencian de un banco tradicional.</p>
        <p>El formulario de contacto aparece al final de cada página con los mismos campos, entre ellos la actividad económica, que el asesor necesita para estudiar el crédito.</p>
        <h2 class="h-s" style="margin:32px 0 16px">Resultados</h2>
        <p>El sitio se publicó. No tengo datos de uso ni de conversión.</p>
      </div>
    </div>'''],
  tones=('mantel', 'bruma', 'mantel'))

# ================================================================ FAIRPLAY
page('fairplay', 'e-Core · Sitio web para Fairplay',
  'Explicar el financiamiento basado en ventas a tiendas en línea',
  'Fairplay ofrece capital a negocios de e-commerce en México y lo cobra según sus ventas. Diseñé el sitio para que una tienda entendiera rápido cómo funciona y diera el siguiente paso.',
  [('Mi rol', 'Diseño web de la home y las páginas internas'), ('Cliente', 'Fairplay, a través de la agencia e-Core'), ('Pantallas', 'Escritorio'), ('Herramientas', 'Figma')],
  [('Objetivo del proyecto', 'Aumentar los leads un 30 % en seis meses. Era la meta definida, no un resultado medido.'),
   ('Mi aporte', 'Diseño visual de la home y las páginas internas a partir del guion de UX writing.'),
   ('Resultado', 'El sitio se publicó. Sin acceso a datos posteriores al lanzamiento.')],
  [f'''{browser('fpView', 'Fairplay, home', 'fp-home', 1440, 6848, 'Home de Fairplay', 'Home: «¡El capital no tiene límite!», por qué Fairplay, cómo funciona, clientes, blog y medios.')}
    {body('Contexto', '<p>Fairplay era cliente de e-Core. Su modelo, el financiamiento basado en ventas, no es tan conocido como un crédito tradicional, así que el sitio tenía que explicarlo antes de pedirle algo al visitante.</p>')}
    <div class="case__body">
      <h2 class="h-s">Objetivos del sitio</h2>
      <div>
        <p class="prose" style="margin-bottom:16px">Estas metas venían definidas en el documento del proyecto (2021). Las presento como objetivos, no como resultados.</p>
        <ul class="goals">
          <li><b>+30 % de leads</b>en los seis meses siguientes al lanzamiento.</li>
          <li><b>Un siguiente paso</b>que cada lead cree una cuenta en Fairplay Insights, pruebe el simulador o pida contacto.</li>
        </ul>
      </div>
    </div>''',
   f'''<div class="case__body" style="margin-top:0">
      <h2 class="h-s">Mi trabajo</h2>
      <div class="prose"><p>Cada página partió de un documento de UX writing del proyecto, que definía los textos de navegación, botones, mensajes de error y de éxito. Ese documento lo elaboró otro equipo. Mi trabajo fue darle forma visual: jerarquía, orden de las secciones y llamados a la acción coherentes en todo el sitio.</p>
      <p>Las páginas cubren a cada público: partners, clientes, productos para e-commerce y marketplace, Fairplay Insights, equipo y blog.</p></div>
    </div>
    <figure class="wire"><img src="../assets/img/fp-uxwriting.webp" width="2400" height="902" alt="Vista general en Figma de las páginas del sitio de Fairplay" data-zoom data-cap="Páginas del sitio de Fairplay en Figma" loading="lazy"></figure>
    <p class="muted" style="font-size:14px;margin-top:12px">Vista general de las páginas diseñadas en Figma.</p>
    {ECORE_SHORT}
    {body('Decisión clave: navegar por público', '<p>Fairplay habla con públicos muy distintos: tiendas en línea, vendedores de marketplace, posibles partners y quienes quieren conocer la empresa. En vez de un menú largo, agrupé las páginas en cinco entradas, Productos, Company, Partner, Clientes y Recursos, y cada una abre su propio submenú. Así cada visitante ve primero lo que le corresponde.</p>')}
    {body('Resultados', '<p>El sitio se publicó. No tuve acceso a los datos posteriores al lanzamiento, por lo que no puedo confirmar si se alcanzó el objetivo de crecimiento de leads.</p>')}'''],
  tones=('mantel', 'bruma'))

# ================================================================ ARCH LIGHT
page('archlight', 'e-Core · Sitio web para Arch Light',
  'Un portafolio de fotografía donde la interfaz se hace a un lado',
  'Arch Light documenta proyectos de arquitectura e interiorismo, y también ofrece tour virtual y fotografía aérea. Su sitio tenía que mostrar las fotos grandes, sin nada que compita con ellas.',
  [('Mi rol', 'Diseño web: home, proyectos, galería y nosotros'), ('Cliente', 'Arch Light Architectural Photography, a través de e-Core'), ('Pantallas', 'Escritorio'), ('Herramientas', 'Figma')],
  [('Problema', 'Mostrar fotografía de arquitectura sin que la interfaz le quite protagonismo.'),
   ('Mi aporte', 'Composición, navegación y galería del sitio, con la foto como elemento principal.'),
   ('Resultado', 'El sitio se publicó. No tengo datos de uso ni de conversión.')],
  [f'''{body('Contexto', '<p>Arch Light era cliente de e-Core. Para un estudio de fotografía, el sitio es el portafolio: los arquitectos y diseñadores juzgan el trabajo por la calidad de las imágenes.</p>')}
    {ECORE_SHORT}
    <figure class="wire"><img src="../assets/img/al-home.webp" width="1440" height="740" alt="Home de Arch Light con una fotografía a pantalla completa" data-zoom data-group="al" data-cap="Home: la fotografía ocupa toda la pantalla" loading="lazy"></figure>
    <p class="muted" style="font-size:14px;margin-top:12px">Home: la fotografía ocupa toda la pantalla y la interfaz queda en las esquinas.</p>
    <div class="duo">
      {shot('al-projects', 'Grilla de proyectos de Arch Light', 'Proyectos en una grilla regular, para comparar las fotos sin ruido.', 'al', 1440, 740)}
      {shot('al-pop', 'Galería emergente de proyectos', 'Galería emergente: se abre sobre la página y se cierra con un clic.', 'al', 1300, 670)}
    </div>
''',
   f'''<div class="case__body" style="margin-top:0">
      <h2 class="h-s">Decisiones de diseño</h2>
      {steps([('La foto es la página', 'La home rota cinco fotografías a pantalla completa. El logo y el menú son pequeños y quedan en las esquinas.'), ('Composición en grilla', 'Los proyectos se ordenan en una grilla regular, separados en interiores y exteriores, para que las fotos se comparen sin ruido.'), ('Galería sin salir de la página', 'Cada proyecto se abre en una galería emergente y se vuelve a la grilla con un clic.'), ('Tipografía en segundo plano', 'Textos cortos, en pocos tamaños, para que el ojo se quede en la fotografía.')])}
    </div>
    {body('Resultados', '<p>El sitio se publicó. No tengo datos de uso ni de conversión.</p>')}'''],
  tones=('mantel', 'bruma'))


# ================================================================ CHICA CUANTICA
CC_SITEMAP = [('Home', 'Presentación de Juliana, servicios, productos, blog y redes'), ('Juliana', 'Historia y enfoque'), ('Servicios', 'Ocho servicios, cada uno con su página'), ('Talleres', 'Tres talleres con su página'), ('Productos', 'Tienda con kits y lecturas'), ('Blog y contacto', 'Artículos y formulario')]
page('chicacuantica', 'e-Core · Sitio web para Chica Cuántica',
  'Un sitio de astrología y coaching que se siente vivo',
  'Chica Cuántica es el proyecto de Juliana Berrio: lecturas de carta natal, coaching, talleres y productos. El sitio tenía que mostrar mucha oferta sin perder calma, y llevar a cada persona del interés a la compra.',
  [('Mi rol', 'Arquitectura de información, diseño web y prototipo con microinteracciones'), ('Cliente', 'Chica Cuántica, a través de la agencia e-Core'), ('Pantallas', 'Escritorio'), ('Herramientas', 'Figma')],
  [('Problema', 'Ocho servicios, tres talleres y una tienda que debían convivir sin saturar la página.'),
   ('Mi aporte', 'Estructura del sitio, diseño de cada página y prototipo con hovers, carruseles, overlays y animación de entrada.'),
   ('Estado', 'Diseño y prototipo entregados al cliente. Publicación sin confirmar.')],
  [f'''{browser('ccView', 'Chica Cuántica, home', 'cc-home', 1440, 4133, 'Home de Chica Cuántica', 'La home completa: hero, servicios, productos, blog, Instagram y suscripción.')}
    {body('Contexto', '<p>Chica Cuántica era cliente de e-Core. Juliana combina astrología y coaching, y vende tanto sesiones como talleres y productos físicos, como kits y lecturas de tarot.</p>')}
    {body('Problema', '<p>La oferta es amplia y cada servicio necesita explicar en qué consiste y cuánto cuesta. Si todo eso aparecía de entrada, la página se volvía pesada; si se escondía, la persona no encontraba el precio.</p>')}
    {body('Mi rol', '<p>Organicé la arquitectura del sitio, diseñé todas las páginas y armé el prototipo en Figma con las interacciones que explican el contenido sin llenar la pantalla.</p>')}
    {ECORE_SHORT}''',
   f'''<div class="case__body" style="margin-top:0">
      <h2 class="h-s">Arquitectura de información</h2>
      <div>
        <p class="prose">El menú lleva a seis secciones. Servicios y talleres tienen submenú para llegar directo a cada uno.</p>
        <ul class="smap">{''.join(f'<li><b>{a}</b><span>{b}</span></li>' for a, b in CC_SITEMAP)}</ul>
      </div>
    </div>
    <div class="duo">
      {shot('cc-grid', 'Página de servicios con ocho tarjetas', 'Servicios: cada tarjeta muestra el ícono y el nombre; el detalle aparece al pasar el mouse.', 'cc', 1440, 1330)}
      {shot('cc-pop', 'Popup de suscripción', 'Popup de suscripción al llegar a la home.', 'cc', 756, 556)}
    </div>''',
   f'''<div class="case__body" style="margin-top:0">
      <h2 class="h-s">Decisiones de diseño</h2>
      {steps([('El detalle aparece cuando se pide', 'La tarjeta muestra solo el ícono y el nombre; la descripción, el precio y Comprar aparecen al pasar el mouse.'), ('Carruseles por grupos', 'Servicios, productos y blog se muestran de a tres, con un contador vertical que indica en qué grupo vas.'), ('Movimiento con intención', 'Una sola animación lenta al entrar, para dar la sensación de cielo en movimiento, y nada más que distraiga.'), ('Suscripción en dos lugares', 'Un popup al llegar y un bloque fijo antes del footer, para que nadie se quede sin la opción.')])}
    </div>
    {body('Estado y resultados', '<p>El diseño y el prototipo se entregaron al cliente. No tengo confirmación de que el sitio se haya publicado, así que no lo presento como un sitio en línea, y tampoco tengo datos de uso.</p>')}'''],
  tones=('mantel', 'bruma', 'mantel'))

# ================================================================ FRATERNIDAD
FRAT = {'a': [['frat-home-o', 'Busca tu abuelito'], ['frat-perfil-o', 'Perfil del paciente'], ['frat-control-o', 'Control general'], ['frat-emerg-o', 'Emergencias']]}
page('fraternidad', 'Fraternidad · Prueba técnica de diseño UI',
  'Seguir el cuidado de cada paciente desde el celular',
  'En un hogar geriátrico, cada enfermero atiende a varios adultos mayores con medicamentos, citas y cuidados distintos. La app reúne lo que debe tener en cuenta durante el turno y lo conecta con la familia.',
  [('Mi rol', 'Diseño UX/UI completo de la prueba: flujo, wireframes, guía de estilo, UI kit y pantallas'), ('Pantallas', 'App móvil'), ('Herramientas', 'Figma, Illustrator, Photoshop'), ('Tipo', 'Prueba técnica, no implementada')],
  [('Problema', 'El personal de enfermería necesita ver rápido qué le toca a cada paciente durante el turno.'),
   ('Mi aporte', 'Jerarquía de la información, sistema visual, componentes y pantallas finales.'),
   ('Resultado', 'Prueba técnica de diseño. No se desarrolló ni se publicó.')],
  [f'''{flow('fratTrack', 'frat', 'Solución, pantalla por pantalla', FRAT, 'Toca una pantalla para verla completa.')}
    <div class="case__body">
      <h2 class="h-s">Decisiones de diseño</h2>
      <div class="prose"><p>La jerarquía responde a la pregunta que se hace un enfermero al abrir la app: a quién atiendo, qué le toca y qué hago si algo sale mal.</p></div>
    </div>
    {decisions([('frat-control-o', 'Control general con medicamentos, aseo, comida, terapias y citas', 'El turno como lista de chequeo', 'Medicamentos, aseo, comida, terapias y citas se marcan uno a uno. Al final, una foto de la orden médica y el estado de ánimo del paciente con cinco caras.'),
                ('frat-perfil-o', 'Perfil del paciente con datos, comorbilidades y alergias', 'Lo esencial en una ficha', 'Datos básicos, comorbilidades, alergias y el contacto de emergencia con un botón Llamar, antes de Iniciar control.'),
                ('frat-emerg-o', 'Pantalla de emergencias con el botón Llamar la ambulancia', 'Emergencias a un toque', 'Una pestaña fija en la barra inferior lleva a la línea de ambulancia, con un color distinto al resto de la app.')])}''',
   f'''<div class="case__body" style="margin-top:0">
      <h2 class="h-s">Sistema visual y componentes</h2>
      <div>
        <p class="prose">Un azul de confianza como color principal, y amarillo y coral solo para estados y alertas. Poppins en cuatro pesos, con una escala de 48 a 12 px. Botones, tarjetas, barra de navegación y barra inferior quedaron documentados en un UI kit.</p>
        <ul class="mood" aria-label="Paleta de Fraternidad">
          <li><span style="background:#5297F4"></span>#5297F4</li>
          <li><span style="background:#F2F8FF"></span>#F2F8FF</li>
          <li><span style="background:#EBEBEB"></span>#EBEBEB</li>
          <li><span style="background:#F4C752"></span>#F4C752</li>
          <li><span style="background:#F46552"></span>#F46552</li>
        </ul>
      </div>
    </div>
    <div class="duo">
      {shot('frat-manual', 'Guía de estilo de Fraternidad', 'Guía de estilo: color, identificador, tipografía, jerarquía e íconos.', 'fr', 1203, 2220)}
      {shot('frat-uikit', 'UI kit de Fraternidad', 'UI kit: botones, tarjetas, barra de navegación y barra inferior.', 'fr', 1083, 2400)}
    </div>''',
   f'''<div class="case__body" style="margin-top:0">
      <h2 class="h-s">Proceso: del wireframe al flujo final</h2>
      <div class="prose"><p>Primero definí el recorrido completo en baja fidelidad: inicio, inicio de sesión, registro del enfermero con su cédula, IPS y código médico, búsqueda del paciente, control, notificaciones y mensajes de la familia. Después lo llevé a alta fidelidad manteniendo las mismas conexiones.</p></div>
    </div>
    <div class="duo">
      {shot('frat-wireframes', 'Wireframes con el flujo de navegación', 'Wireframes de baja fidelidad con el flujo de navegación.', 'fr2', 1361, 1950)}
      {shot('frat-flujo', 'Pantallas finales conectadas en el flujo de usuario', 'Pantallas finales conectadas en el flujo de usuario.', 'fr2', 1320, 2400)}
    </div>'''],
  tones=('mantel', 'bruma', 'mantel'),
  note='Proyecto realizado para una prueba técnica de diseño UI. No es un producto en producción.')

# ================================================================ HUELLAS UNIDAS
HU_LABELS = ['Home: mascotas perdidas cerca','Paso 1: datos de la mascota','Pregunta por una foto reciente','Paso 1 con la foto cargada','Paso 2: dónde se perdió','Paso 3: datos de contacto','Vista previa del reporte','Confirmar antes de publicar','Reporte publicado']
HU_LO = {'a': [[f'hu-lo-{k+1}', t] for k, t in enumerate(HU_LABELS)]}
HU_MI = {'a': [[f'hu-mi-{k+1}', t] for k, t in enumerate(HU_LABELS)]}
HU_UI = {'a': [[f'hu-ui-{k+1}', t] for k, t in enumerate(HU_LABELS)]}
SORT = json.dumps([["Búsqueda y reporte",["Crear reporte de mascota perdida","Generador de flyer digital","Estado de la búsqueda"]],["Avistamiento",["Reportar avistamiento","Compartir reporte en redes sociales","Historial de avistamientos reportados","Contacto directo con el tutor"]],["Localización y alertas",["Mapa interactivo de alertas","Notificaciones de avistamientos cercanos","Configuración de alertas y privacidad","Filtro de búsqueda por radio o distancia"]],["Perfil",["Mis reportes activos","Perfil del usuario o tutor","Ficha de detalle de la mascota","Guía de primeros auxilios de búsqueda"]]], ensure_ascii=False)
page('huellas-unidas', 'Coderhouse · Huellas Unidas, app nativa para mascotas perdidas',
  'Reportar una mascota perdida en tres pasos',
  'Cuando una mascota se pierde, quien la busca necesita publicar el aviso rápido y que llegue a las personas cercanas. Huellas Unidas es una app nativa para celular que reúne el reporte, los avistamientos y las alertas por ubicación.',
  [('Mi rol', 'Proceso UX/UI del proyecto: investigación, arquitectura de información, wireframes y diseño visual'), ('Plataforma', 'App nativa para celular'), ('Métodos', 'Entrevistas, encuestas, card sorting y wireframes en Figma'), ('Estado', 'En curso: wireframes, moodboard, UI kit y media fidelidad con diseño visual')],
  [('Problema', 'Publicar un aviso de mascota perdida suele ser lento y disperso entre redes y grupos.'),
   ('Mi aporte', 'Desk research, benchmark, 5 entrevistas, encuesta a 14 personas, card sorting con 4 participantes, arquitectura de información, wireframes, moodboard y UI kit.'),
   ('Resultado', 'Todavía no hay resultados de uso: es un proyecto académico en curso.')],
  [f'''<figure class="pill" data-pill>
      <div class="pill__clip"><img src="../assets/img/hu-hero.webp" width="1440" height="760" alt="La home de Huellas Unidas en tres momentos: baja fidelidad, media fidelidad y media fidelidad con diseño visual" data-zoom data-cap="Huellas Unidas: de la baja fidelidad al diseño visual"></div>
      <figcaption>Una app nativa pensada solo para el celular, que es donde la persona busca a su mascota.</figcaption>
    </figure>
    {body('Contexto', '<p>Huellas Unidas es mi proyecto de la carrera de Diseño UX/UI en Coderhouse. El trabajo se enfoca en la app nativa para celular: investigación, arquitectura de información, wireframes y, en el módulo actual, diseño visual.</p>')}
    {body('Problema', '<p>Cuando una mascota se pierde, el tiempo cuenta y la persona está en la calle, con el celular en la mano. El reto era que crear el reporte fuera corto y sin errores, y que la app ordenara muchas funciones distintas sin volverse confusa.</p>')}
    <div class="case__body">
      <h2 class="h-s">Investigación</h2>
      <div>
        <p class="prose">Antes de definir la estructura de la app combiné investigación de escritorio, un benchmark de dos apps y conversaciones con dueños de mascotas.</p>
        <ul class="stats">
          <li><b>5</b>entrevistas en profundidad</li>
          <li><b>14</b>respuestas a una encuesta en línea</li>
          <li><b>2</b>apps analizadas: PawBoost y Finding Rover</li>
          <li><b>4</b>participantes en el card sorting</li>
        </ul>
      </div>
    </div>
    <div class="case__body">
      <h2 class="h-s">Lo que encontré</h2>
      {steps([('Un patrón que apareció en las cinco entrevistas', 'Las cinco personas entrevistadas contaron que, al notar la pérdida de su mascota, su primera reacción fue salir a buscarla sin tener una orientación clara. Esto evidenció la necesidad de ofrecer información que ayude a organizar la búsqueda desde el primer momento.'), ('Lo que más frustra es no saber qué pasa', '7 de las 14 personas encuestadas dijeron que su mayor frustración fue no conocer en tiempo real el estado de la búsqueda. El problema no es solo difundir la alerta, también seguirla.'), ('Los carteles cuestan tiempo y llegan poco', 'Entrevistados y encuestados coincidieron en que imprimir y pegar carteles toma mucho tiempo y tiene poco alcance. Las redes ayudan, pero la información queda dispersa.'), ('La búsqueda empieza cerca de casa', 'La investigación de escritorio mostró que buscar en los alrededores es una de las acciones más importantes para encontrar una mascota. En una encuesta nacional en Estados Unidos, recorrer el vecindario fue la forma más común en que los dueños recuperaron a sus perros (<a href="https://pmc.ncbi.nlm.nih.gov/articles/PMC4494319/" target="_blank" rel="noopener">Weiss, Slater y Lord, revista Animals, 2012</a>).')])}
    </div>
    {body('Benchmark', '<p>Analicé PawBoost y Finding Rover. Las dos resuelven bien la navegación y piden solo la información justa. En el momento del análisis, sus interfaces estaban en inglés, no encontré cobertura en Bogotá y había problemas de jerarquía y contraste en filtros y textos. Son observaciones del benchmark hecho en 2026, no una descripción permanente de esos servicios. De ahí salieron tres oportunidades para Huellas Unidas: estar en español, ser local y tener una jerarquía clara.</p>')}
    <div class="case__body">
      <h2 class="h-s">Dos momentos que la app debe resolver</h2>
      <ul class="goals">
        <li><b>Difusión inmediata</b>El dueño necesita activar una alerta en su comunidad cercana apenas nota la pérdida, porque los métodos manuales consumen el tiempo más valioso.</li>
        <li><b>Búsqueda con seguimiento</b>Durante la búsqueda necesita coordinar acciones con reportes en tiempo real, para no salir sin rumbo ni perder el control.</li>
      </ul>
    </div>
    <section class="sort" aria-labelledby="sortT">
      <div class="case__body">
        <h2 class="h-s" id="sortT">Card sorting: 15 funciones en cuatro grupos</h2>
        <div class="prose"><p>Hice un card sorting híbrido en UXTests con 4 participantes y 15 tarjetas. El acuerdo promedio entre participantes fue del 32 %. En este ejercicio exploratorio, la baja coincidencia mostró que las personas organizaban las funciones de distintas maneras. Después de analizar esos patrones, definí los cuatro grupos finales que estructuran la navegación. Agrupa las tarjetas para verlos.</p></div>
      </div>
      <div class="sort__bar">
        <button type="button" class="btn btn--solid" id="sortBtn" aria-pressed="false">Agrupar tarjetas</button>
        <span class="muted" id="sortNote" aria-live="polite">15 tarjetas sin ordenar</span>
      </div>
      <div class="sort__board" id="sortBoard" data-groups='{SORT}'></div>
    </section>
    <div class="case__body">
      <h2 class="h-s">De los hallazgos a la arquitectura</h2>
      <div><div class="prose" style="margin-bottom:24px"><p>Los cuatro grupos parten de la organización de contenido que propuse antes del ejercicio. Después de analizar las categorías que crearon los participantes, los mantuve como categorías finales y los relacioné con lo que encontré en la investigación.</p></div>
      {steps([('Búsqueda y reporte', 'Crear el reporte, el generador de flyer digital y el estado de la búsqueda. Responde a la difusión inmediata: activar la alerta en un solo recorrido.'), ('Avistamiento', 'Reportar un avistamiento, compartir el reporte en redes, el historial de avistamientos y el contacto directo con el tutor. Responde a la frustración de no saber qué pasa durante la búsqueda.'), ('Localización y alertas', 'El mapa interactivo, las notificaciones de avistamientos cercanos, el filtro por radio o distancia y la configuración de alertas. Responde a que la búsqueda empieza cerca de casa.'), ('Perfil', 'Mis reportes activos, el perfil del tutor, la ficha de la mascota y la guía de primeros auxilios de búsqueda. No sale de un hallazgo puntual: reúne la información propia del usuario y la guía de consulta.')])}</div>
    </div>
    <figure class="wire"><img src="../assets/img/firu-sitemap.webp" width="2048" height="1029" alt="Mapa de navegación de Huellas Unidas: Home con Búsqueda, Avistamiento, Localización y Perfil" data-zoom data-cap="Mapa de navegación (site map)" loading="lazy"></figure>
    <p class="muted" style="font-size:14px;margin-top:12px">Mapa de navegación: los cuatro grupos como secciones bajo la home (Búsqueda, Avistamiento, Localización y Perfil).</p>''',
   f'''<div class="case__body" style="margin-top:0">
      <h2 class="h-s">Flujo principal: reportar una mascota</h2>
      <div class="prose"><p>Del inicio a la alerta publicada, con dos decisiones en el camino: si hay una foto actual de la mascota (si no, se usa un avatar ilustrado) y si los datos de la vista previa son correctos antes de publicar.</p></div>
    </div>
    <div class="scrollx"><img src="../assets/img/firu-userflow.webp" width="2048" height="296" alt="User flow del reporte de mascota perdida, del inicio al reporte publicado" data-zoom data-cap="User flow del reporte" loading="lazy"></div>
    <div class="case__body">
      <h2 class="h-s">Decisiones de navegación</h2>
      {steps([('Tab bar inferior', 'Cuatro accesos fijos que se alcanzan con el pulgar. En los wireframes eran Inicio, Mis alertas, Reportar y Perfil; en la versión con diseño visual pasaron a Búsqueda, Avistamiento, Alertas y Perfil, alineados con los grupos del card sorting.'), ('Reportar siempre a la vista', 'El botón Reportar mascota tiene la jerarquía visual más fuerte, para que nadie pierda tiempo buscando cómo empezar.'), ('Tres pasos cortos', 'El formulario se divide en datos de la mascota, ubicación y hora, y datos de contacto, para bajar la carga en un momento de ansiedad.'), ('Saber en qué punto se está', 'Indicador de paso, vista previa antes de publicar y confirmación con el pin activo en el mapa.')])}
    </div>
    <div class="case__body">
      <h2 class="h-s">Wireframes de baja fidelidad</h2>
      <div class="prose"><p>El flujo completo del reporte en bloques grises: de la home a la publicación, en nueve pantallas. Sirvió para definir el orden de los pasos antes de escribir los textos.</p></div>
    </div>
    {flow('huLo', 'firu', 'Baja fidelidad: el reporte completo', HU_LO, 'Nueve pantallas. Toca una para ampliarla.')}
    <div class="case__body">
      <h2 class="h-s">Wireframes de media fidelidad</h2>
      <div class="prose"><p>El mismo flujo de nueve pantallas con textos reales, jerarquía y la barra de navegación inferior. Aquí se definen los mensajes de cada paso, como «¡Vamos a crear tu reporte!» o «¡Ya solo queda un paso!».</p></div>
    </div>
    {flow('huMi', 'firu', 'Media fidelidad: el reporte completo', HU_MI, 'Nueve pantallas. Toca una para ampliarla.')}''',
   f'''<section class="ba" aria-labelledby="baT">
      <div class="case__body" style="margin-top:0">
        <h2 class="h-s" id="baT">De baja a media fidelidad</h2>
        <div class="prose"><p>La misma pantalla en dos momentos: primero la estructura con bloques grises, luego el texto real y la jerarquía. Arrastra el control para comparar.</p></div>
      </div>
      <div class="ba__wrap">
        <div class="ba__frame" id="baFrame" style="--p:50%">
          <img src="../assets/img/hu-mi-3.webp" alt="Media fidelidad: diálogo ¿Tienes foto reciente de tu mascota?" width="402" height="874" loading="lazy">
          <img class="ba__top" src="../assets/img/hu-lo-3.webp" alt="Baja fidelidad de la misma pantalla" width="402" height="874" loading="lazy">
          <span class="ba__line" aria-hidden="true"><span>↔</span></span>
          <span class="ba__tag ba__tag--l" aria-hidden="true">Baja</span><span class="ba__tag ba__tag--r" aria-hidden="true">Media</span>
        </div>
        <label class="sr" for="baRange">Comparar baja y media fidelidad</label>
        <input type="range" id="baRange" min="0" max="100" value="50" class="ba__range">
        <ul class="ba__notes">
          <li><b>La pregunta explica el porqué.</b>Un diálogo pregunta si hay una foto reciente antes de pedirla.</li>
          <li><b>Progreso visible.</b>Cada pantalla dice en qué paso va el reporte, de uno a tres.</li>
          <li><b>Una acción principal.</b>Continuar siempre está en el mismo lugar y Cerrar queda como secundaria.</li>
        </ul>
      </div>
    </section>
    <div class="case__body">
      <h2 class="h-s">Moodboard y paleta</h2>
      <div>
        <p class="prose">Reuní referentes de apps de mascotas para encontrar patrones de diagramación, jerarquía, estilos de imagen y color. Elegí una paleta que transmitiera tres ideas: confianza, esperanza y claridad.</p>
        <ul class="mood" aria-label="Paleta de Huellas Unidas">
          <li><span style="background:#36ECDE"></span>#36ECDE</li>
          <li><span style="background:#3F5C40"></span>#3F5C40</li>
          <li><span style="background:#F6694E"></span>#F6694E</li>
          <li><span style="background:#F7F9E1"></span>#F7F9E1</li>
          <li><span style="background:#B2E7D5"></span>#B2E7D5</li>
        </ul>
      </div>
    </div>
    <figure class="wire"><img src="../assets/img/hu-moodboard.webp" width="1440" height="1173" alt="Moodboard con referentes de apps de mascotas y la paleta de Huellas Unidas" data-zoom data-cap="Moodboard: referentes, palabras clave y paleta" loading="lazy"></figure>
    <p class="muted" style="font-size:14px;margin-top:12px">Moodboard con referentes de apps de mascotas, las tres palabras clave y la paleta elegida.</p>
    <div class="case__body">
      <h2 class="h-s">UI kit y media fidelidad con diseño visual</h2>
      <div class="prose"><p>Armé un UI kit con los componentes de la app: barra de estado, tab bar, buscador, campos de texto, alerta, tarjeta de mascota e íconos propios para búsqueda, avistamiento, alertas y perfil. El botón tiene cuatro estados: principal, secundario, error y desactivado. Con ese kit llevé el flujo del reporte a media fidelidad con fotos, color y el nombre de la app.</p></div>
    </div>
    {flow('huUi', 'firu', 'Media fidelidad con diseño visual', HU_UI, 'Nueve pantallas. Toca una para ampliarla.')}
    {body('Uso de IA', '<p>Usé Gemini como apoyo en la investigación de escritorio, en la redacción de las preguntas de entrevistas y encuesta, y en la síntesis de resultados. Para el moodboard me apoyé en ChatGPT para generar ideas de color a partir de los colores base que seleccioné. El análisis de puntos de dolor, insights, el punto de vista y las decisiones de diseño fueron míos.</p>')}
    {body('Próximos pasos', '<p>El proyecto sigue en la carrera. Cuando avance a las siguientes etapas, este caso se actualizará con el nuevo material.</p>')}'''],
  tones=('bruma', 'mantel', 'bruma'),
  note='Proyecto académico de la carrera de Diseño UX/UI en Coderhouse, en curso. App nativa para celular.')

# ================================================================ HOME
META = {'onboarding':'Producto SaaS, escritorio a móvil','domicilios':'E-commerce, móvil, tablet y escritorio','planautos':'Sitio web, finanzas','fairplay':'Sitio web, fintech','archlight':'Sitio web, fotografía','chicacuantica':'Sitio web, bienestar','fraternidad':'App móvil, prueba técnica','huellas-unidas':'App nativa, proyecto académico'}
def row(p, main=False):
    d = f'<span class="row__d">{p["desc"]}</span>' if main else ''
    return f"""<li><a href="trabajo/{p['slug']}.html" data-peek="assets/img/{p['img']}.webp"><img class="row__thumb" src="assets/img/thumb-{p['img']}.webp" alt="" loading="lazy" width="88" height="66"><span class="row__t">{p['title']}{d}</span><span class="row__m">{META[p['slug']]}</span><svg class="row__go" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4"/></svg></a></li>"""
groups_html = ''
for key, name, sub in GROUPS:
    main = key == 'precompro'
    rows = ''.join(row(p, main) for p in P if p['group'] == key)
    badge = '<em class="group__badge">Experiencia principal</em>' if main else ''
    groups_html += f"""
      <div class="group{' group--main' if main else ''}">
        <p class="group__name">{badge}<b>{name}</b><span>{sub}</span></p>
        <ul>{rows}</ul>
      </div>"""

LD = json.dumps({
  "@context": "https://schema.org", "@type": "ProfilePage",
  "mainEntity": {
    "@type": "Person", "name": "Norberto Sánchez Cañón",
    "jobTitle": "UI/UX Designer, Product Designer y Web Designer",
    "description": "Diseñador UI/UX con más de 10 años en diseño y 3 años en producto digital.",
    "email": "mailto:" + MAIL,
    "address": {"@type": "PostalAddress", "addressLocality": "Bogotá", "addressCountry": "CO"},
    "sameAs": [LI, "https://www.behance.net/norbertosanchezc"],
    "knowsAbout": ["Diseño de interfaces", "Diseño UX/UI", "Diseño web", "Diseño responsive", "Prototipado", "Figma"],
    "alumniOf": {"@type": "EducationalOrganization", "name": "Coderhouse"},
    "worksFor": None
  }
}, ensure_ascii=False).replace(', "worksFor": null', '')

home = head('Norberto Sánchez Cañón | UI/UX Designer, Product Designer y Web Designer',
            'Diseñador UI/UX en Bogotá. Más de 10 años en diseño y 3 años como único diseñador de producto en Precompro. Interfaces claras para web y apps, del flujo a la implementación.', '',
            '', None, f'<script type="application/ld+json">{LD}</script>\n')
home += '<body data-tone="pizarra" data-img="assets/img/">\n' + chrome('', True)
home += f"""
<main id="main" tabindex="-1">

<section class="hero" id="inicio" data-tone="pizarra">
  <div class="wrap">
    <div class="hero__grid">
      <div class="hero__copy">
        <p class="hero__role"><span>UI/UX Designer</span><span>Product Designer</span><span>Web Designer</span></p>
        <h1 class="h-xl" data-rise aria-label="Diseñador UX/UI de producto digital. Interfaces claras, listas para desarrollo.">
          <span class="l"><span>Diseñador UX/UI</span></span>
          <span class="l"><span>de producto digital.</span></span>
          <span class="l l--soft"><span>Interfaces claras,</span></span>
          <span class="l l--soft"><span>listas para desarrollo.</span></span>
        </h1>
        <p class="lede">Tengo más de 10 años de experiencia en diseño, con trayectoria en diseño gráfico, publicidad y diseño web. Durante tres años fui el único diseñador de producto en Precompro: definía flujos, diseñaba interfaces y acompañaba al equipo de desarrollo hasta la implementación. Actualmente profundizo mis conocimientos de UX en la carrera de Diseño UX/UI de Coderhouse.</p>
        <div class="hero__actions">
          <a class="btn btn--solid" href="#proyectos">Ver proyectos</a>
          <a class="btn" href="assets/Norberto_Sanchez_Canon_CV.pdf" target="_blank" rel="noopener">Descargar CV<span class="sr"> (PDF, abre en una pestaña nueva)</span></a>
        </div>
      </div>
      <figure class="face" id="face">
        <div class="face__pill"><img src="assets/img/norberto.webp" alt="Retrato de Norberto Sánchez" width="760" height="1013" fetchpriority="high"></div>
      </figure>
    </div>

    <ul class="strengths" aria-label="Fortalezas">
      <li><b>De la idea a producción</b><span>Defino flujos, wireframes y prototipos en Figma, y acompaño cada diseño durante su construcción hasta la implementación.</span></li>
      <li><b>Cada pantalla pensada</b><span>Diseño experiencias para escritorio, tablet y móvil, adaptando los flujos y las interfaces al contexto de uso de cada dispositivo.</span></li>
      <li><b>Criterio visual</b><span>Mi experiencia en publicidad e identidad visual se refleja en la jerarquía, la tipografía y la coherencia de cada interfaz.</span></li>
      <li><b>Trabajo con desarrollo</b><span>Documento las entregas en Jira, preparo especificaciones y mantengo comunicación directa con el equipo técnico durante la implementación.</span></li>
    </ul>

    <dl class="facts facts--5">
      <div><dt>Busco</dt><dd>UI/UX Designer, Product Designer o Web Designer</dd></div>
      <div><dt>Experiencia en diseño</dt><dd>Más de 10 años, desde 2011</dd></div>
      <div><dt>Proyectos digitales</dt><dd>Alrededor de 4 años, 3 de ellos en producto digital en Precompro</dd></div>
      <div><dt>Herramientas</dt><dd>Figma, Adobe XD, Sketch, Jira, Adobe Creative Cloud</dd></div>
      <div><dt>Formación actual</dt><dd>Diseño UX/UI en Coderhouse, sept. 2026 – jun. 2027</dd></div>
    </dl>
  </div>
</section>

<section class="section" id="proyectos" data-tone="bruma" aria-labelledby="pT">
  <div class="wrap">
    <div class="sec-head">
      <h2 class="h-l" id="pT">Proyectos</h2>
      <p>Producto digital en Precompro, sitios web en una agencia, una prueba técnica y un proyecto académico. Entra a cada uno para ver el caso completo.</p>
    </div>
    <div class="groups" id="index">{groups_html}
    </div>
  </div>
</section>

<section class="section" id="sobre-mi" data-tone="pizarra" aria-labelledby="abT">
  <div class="wrap about">
    <figure class="about__photo"><img src="assets/img/norberto-trabajo.webp" alt="Norberto sentado en el piso con ropa deportiva, sonriendo" loading="lazy" width="900" height="1200"></figure>
    <div>
      <h2 class="h-m" id="abT">Cómo trabajo</h2>
      <p class="lede" style="margin-top:24px">Me gusta trabajar cerca de los equipos de producto y desarrollo para convertir necesidades en soluciones visuales claras. Valoro la organización, la comunicación y el seguimiento durante todo el proceso, desde la primera propuesta hasta la implementación. Actualmente busco seguir creciendo en diseño de producto y profundizar mis conocimientos de UX.</p>
      <ul class="traits">
        <li><b>Ordenado</b><span>Archivos, componentes y entregas que cualquier persona del equipo puede entender y retomar.</span></li>
        <li><b>Estructurado</b><span>Divido cada proyecto en etapas claras, del flujo a la entrega final.</span></li>
        <li><b>Constante</b><span>Hago seguimiento durante la implementación y mantengo el ritmo hasta terminar.</span></li>
      </ul>
      <div class="sport">
        <ul class="sports" aria-label="Deportes"><li>Running</li><li>Ciclismo</li><li>Natación</li></ul>
        <p>Fuera del trabajo entreno running, ciclismo y natación. El deporte me enseñó a planear por etapas y a cumplir lo que me propongo.</p>
      </div>
    </div>
  </div>
</section>

<section class="contact" id="contacto" data-tone="carbon" aria-labelledby="ctT">
  <div class="wrap">
    <h2 class="h-l" id="ctT">¿Tienes una vacante de UI/UX o diseño web?</h2>
    <button class="mail" type="button" id="mailBtn" aria-describedby="mailHint">
      <span class="mail__addr">{MAIL}</span>
      <span class="mail__hint" id="mailHint">Toca para copiar el correo</span>
    </button>
    <div class="contact__grid">
      <a class="cbox" href="{LI}" target="_blank" rel="noopener"><span>LinkedIn</span><b>in/norbertosanchez</b></a>
      <a class="cbox" href="{WA}" target="_blank" rel="noopener"><span>WhatsApp</span><b>+57 311 381 1872</b></a>
      <a class="cbox" href="assets/Norberto_Sanchez_Canon_CV.pdf" target="_blank" rel="noopener"><span>Hoja de vida</span><b>Descargar CV en PDF</b></a>
    </div>
    <footer class="foot">
      <span>Bogotá, Colombia. Disponible para trabajo híbrido o remoto.</span>
      <a href="#inicio">Volver arriba</a>
    </footer>
  </div>
</section>
</main>
"""
home += '\n<div class="peek" id="peek" aria-hidden="true"><img alt="" id="peekImg"></div>'
home += tail('')
with open(os.path.join(ROOT, 'index.html'), 'w') as f:
    f.write(home)
print('ok')
